/*
 * Copyright (c) 2023, Texas Instruments Incorporated - http://www.ti.com
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ============ ti_msp_dl_config.h =============
 *  Configured MSPM0 DriverLib module declarations
 *
 *  DO NOT EDIT - This file is generated for the MSPM0G350X
 *  by the SysConfig tool.
 */
#ifndef ti_msp_dl_config_h
#define ti_msp_dl_config_h

#define CONFIG_MSPM0G350X

#if defined(__ti_version__) || defined(__TI_COMPILER_VERSION__)
#define SYSCONFIG_WEAK __attribute__((weak))
#elif defined(__IAR_SYSTEMS_ICC__)
#define SYSCONFIG_WEAK __weak
#elif defined(__GNUC__)
#define SYSCONFIG_WEAK __attribute__((weak))
#endif

#include <ti/devices/msp/msp.h>
#include <ti/driverlib/driverlib.h>
#include <ti/driverlib/m0p/dl_core.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 *  ======== SYSCFG_DL_init ========
 *  Perform all required MSP DL initialization
 *
 *  This function should be called once at a point before any use of
 *  MSP DL.
 */


/* clang-format off */

#define POWER_STARTUP_DELAY                                                (16)


#define CPUCLK_FREQ                                                     32000000



/* Defines for PWMa */
#define PWMa_INST                                                          TIMA1
#define PWMa_INST_IRQHandler                                    TIMA1_IRQHandler
#define PWMa_INST_INT_IRQN                                      (TIMA1_INT_IRQn)
#define PWMa_INST_CLK_FREQ                                              32000000
/* GPIO defines for channel 0 */
#define GPIO_PWMa_C0_PORT                                                  GPIOB
#define GPIO_PWMa_C0_PIN                                          DL_GPIO_PIN_26
#define GPIO_PWMa_C0_IOMUX                                       (IOMUX_PINCM57)
#define GPIO_PWMa_C0_IOMUX_FUNC                      IOMUX_PINCM57_PF_TIMA1_CCP0
#define GPIO_PWMa_C0_IDX                                     DL_TIMER_CC_0_INDEX
/* GPIO defines for channel 1 */
#define GPIO_PWMa_C1_PORT                                                  GPIOB
#define GPIO_PWMa_C1_PIN                                          DL_GPIO_PIN_27
#define GPIO_PWMa_C1_IOMUX                                       (IOMUX_PINCM58)
#define GPIO_PWMa_C1_IOMUX_FUNC                      IOMUX_PINCM58_PF_TIMA1_CCP1
#define GPIO_PWMa_C1_IDX                                     DL_TIMER_CC_1_INDEX

/* Defines for Duoji */
#define Duoji_INST                                                         TIMG6
#define Duoji_INST_IRQHandler                                   TIMG6_IRQHandler
#define Duoji_INST_INT_IRQN                                     (TIMG6_INT_IRQn)
#define Duoji_INST_CLK_FREQ                                             32000000
/* GPIO defines for channel 0 */
#define GPIO_Duoji_C0_PORT                                                 GPIOA
#define GPIO_Duoji_C0_PIN                                         DL_GPIO_PIN_21
#define GPIO_Duoji_C0_IOMUX                                      (IOMUX_PINCM46)
#define GPIO_Duoji_C0_IOMUX_FUNC                     IOMUX_PINCM46_PF_TIMG6_CCP0
#define GPIO_Duoji_C0_IDX                                    DL_TIMER_CC_0_INDEX
/* GPIO defines for channel 1 */
#define GPIO_Duoji_C1_PORT                                                 GPIOA
#define GPIO_Duoji_C1_PIN                                          DL_GPIO_PIN_6
#define GPIO_Duoji_C1_IOMUX                                      (IOMUX_PINCM11)
#define GPIO_Duoji_C1_IOMUX_FUNC                     IOMUX_PINCM11_PF_TIMG6_CCP1
#define GPIO_Duoji_C1_IDX                                    DL_TIMER_CC_1_INDEX



/* Defines for Xunji_task */
#define Xunji_task_INST                                                  (TIMG0)
#define Xunji_task_INST_IRQHandler                              TIMG0_IRQHandler
#define Xunji_task_INST_INT_IRQN                                (TIMG0_INT_IRQn)
#define Xunji_task_INST_LOAD_VALUE                                      (19999U)
/* Defines for Yuntai_task */
#define Yuntai_task_INST                                                 (TIMA0)
#define Yuntai_task_INST_IRQHandler                             TIMA0_IRQHandler
#define Yuntai_task_INST_INT_IRQN                               (TIMA0_INT_IRQn)
#define Yuntai_task_INST_LOAD_VALUE                                     (19999U)




/* Defines for OLED */
#define OLED_INST                                                           I2C1
#define OLED_INST_IRQHandler                                     I2C1_IRQHandler
#define OLED_INST_INT_IRQN                                         I2C1_INT_IRQn
#define OLED_BUS_SPEED_HZ                                                 100000
#define GPIO_OLED_SDA_PORT                                                 GPIOB
#define GPIO_OLED_SDA_PIN                                          DL_GPIO_PIN_3
#define GPIO_OLED_IOMUX_SDA                                      (IOMUX_PINCM16)
#define GPIO_OLED_IOMUX_SDA_FUNC                       IOMUX_PINCM16_PF_I2C1_SDA
#define GPIO_OLED_SCL_PORT                                                 GPIOB
#define GPIO_OLED_SCL_PIN                                          DL_GPIO_PIN_2
#define GPIO_OLED_IOMUX_SCL                                      (IOMUX_PINCM15)
#define GPIO_OLED_IOMUX_SCL_FUNC                       IOMUX_PINCM15_PF_I2C1_SCL


/* Defines for vofa_uart */
#define vofa_uart_INST                                                     UART1
#define vofa_uart_INST_IRQHandler                               UART1_IRQHandler
#define vofa_uart_INST_INT_IRQN                                   UART1_INT_IRQn
#define GPIO_vofa_uart_RX_PORT                                             GPIOA
#define GPIO_vofa_uart_TX_PORT                                             GPIOA
#define GPIO_vofa_uart_RX_PIN                                      DL_GPIO_PIN_9
#define GPIO_vofa_uart_TX_PIN                                      DL_GPIO_PIN_8
#define GPIO_vofa_uart_IOMUX_RX                                  (IOMUX_PINCM20)
#define GPIO_vofa_uart_IOMUX_TX                                  (IOMUX_PINCM19)
#define GPIO_vofa_uart_IOMUX_RX_FUNC                   IOMUX_PINCM20_PF_UART1_RX
#define GPIO_vofa_uart_IOMUX_TX_FUNC                   IOMUX_PINCM19_PF_UART1_TX
#define vofa_uart_BAUD_RATE                                             (115200)
#define vofa_uart_IBRD_32_MHZ_115200_BAUD                                   (17)
#define vofa_uart_FBRD_32_MHZ_115200_BAUD                                   (23)
/* Defines for see_uart */
#define see_uart_INST                                                      UART2
#define see_uart_INST_IRQHandler                                UART2_IRQHandler
#define see_uart_INST_INT_IRQN                                    UART2_INT_IRQn
#define GPIO_see_uart_RX_PORT                                              GPIOB
#define GPIO_see_uart_TX_PORT                                              GPIOB
#define GPIO_see_uart_RX_PIN                                      DL_GPIO_PIN_16
#define GPIO_see_uart_TX_PIN                                      DL_GPIO_PIN_15
#define GPIO_see_uart_IOMUX_RX                                   (IOMUX_PINCM33)
#define GPIO_see_uart_IOMUX_TX                                   (IOMUX_PINCM32)
#define GPIO_see_uart_IOMUX_RX_FUNC                    IOMUX_PINCM33_PF_UART2_RX
#define GPIO_see_uart_IOMUX_TX_FUNC                    IOMUX_PINCM32_PF_UART2_TX
#define see_uart_BAUD_RATE                                              (115200)
#define see_uart_IBRD_32_MHZ_115200_BAUD                                    (17)
#define see_uart_FBRD_32_MHZ_115200_BAUD                                    (23)
/* Defines for Liangan */
#define Liangan_INST                                                       UART3
#define Liangan_INST_IRQHandler                                 UART3_IRQHandler
#define Liangan_INST_INT_IRQN                                     UART3_INT_IRQn
#define GPIO_Liangan_RX_PORT                                               GPIOB
#define GPIO_Liangan_TX_PORT                                               GPIOB
#define GPIO_Liangan_RX_PIN                                       DL_GPIO_PIN_13
#define GPIO_Liangan_TX_PIN                                       DL_GPIO_PIN_12
#define GPIO_Liangan_IOMUX_RX                                    (IOMUX_PINCM30)
#define GPIO_Liangan_IOMUX_TX                                    (IOMUX_PINCM29)
#define GPIO_Liangan_IOMUX_RX_FUNC                     IOMUX_PINCM30_PF_UART3_RX
#define GPIO_Liangan_IOMUX_TX_FUNC                     IOMUX_PINCM29_PF_UART3_TX
#define Liangan_BAUD_RATE                                               (115200)
#define Liangan_IBRD_32_MHZ_115200_BAUD                                     (17)
#define Liangan_FBRD_32_MHZ_115200_BAUD                                     (23)




/* Defines for BMI088 */
#define BMI088_INST                                                        SPI0
#define BMI088_INST_IRQHandler                                  SPI0_IRQHandler
#define BMI088_INST_INT_IRQN                                      SPI0_INT_IRQn
#define GPIO_BMI088_PICO_PORT                                             GPIOB
#define GPIO_BMI088_PICO_PIN                                     DL_GPIO_PIN_17
#define GPIO_BMI088_IOMUX_PICO                                  (IOMUX_PINCM43)
#define GPIO_BMI088_IOMUX_PICO_FUNC                  IOMUX_PINCM43_PF_SPI0_PICO
#define GPIO_BMI088_POCI_PORT                                             GPIOB
#define GPIO_BMI088_POCI_PIN                                     DL_GPIO_PIN_19
#define GPIO_BMI088_IOMUX_POCI                                  (IOMUX_PINCM45)
#define GPIO_BMI088_IOMUX_POCI_FUNC                  IOMUX_PINCM45_PF_SPI0_POCI
/* GPIO configuration for BMI088 */
#define GPIO_BMI088_SCLK_PORT                                             GPIOB
#define GPIO_BMI088_SCLK_PIN                                     DL_GPIO_PIN_18
#define GPIO_BMI088_IOMUX_SCLK                                  (IOMUX_PINCM44)
#define GPIO_BMI088_IOMUX_SCLK_FUNC                  IOMUX_PINCM44_PF_SPI0_SCLK
#define GPIO_BMI088_CS0_PORT                                              GPIOA
#define GPIO_BMI088_CS0_PIN                                       DL_GPIO_PIN_2
#define GPIO_BMI088_IOMUX_CS0                                    (IOMUX_PINCM7)
#define GPIO_BMI088_IOMUX_CS0_FUNC                     IOMUX_PINCM7_PF_SPI0_CS0



/* Defines for DMA_CH0 */
#define DMA_CH0_CHAN_ID                                                      (0)
#define see_uart_INST_DMA_TRIGGER                            (DMA_UART2_RX_TRIG)



/* Port definition for Pin Group tb66_stay */
#define tb66_stay_PORT                                                   (GPIOB)

/* Defines for tb66_stay_pin: GPIOB.6 with pinCMx 23 on package pin 58 */
#define tb66_stay_tb66_stay_pin_PIN                              (DL_GPIO_PIN_6)
#define tb66_stay_tb66_stay_pin_IOMUX                            (IOMUX_PINCM23)
/* Port definition for Pin Group Music */
#define Music_PORT                                                       (GPIOA)

/* Defines for music: GPIOA.7 with pinCMx 14 on package pin 49 */
#define Music_music_PIN                                          (DL_GPIO_PIN_7)
#define Music_music_IOMUX                                        (IOMUX_PINCM14)
/* Port definition for Pin Group DianCiTie */
#define DianCiTie_PORT                                                   (GPIOB)

/* Defines for diancitie: GPIOB.0 with pinCMx 12 on package pin 47 */
#define DianCiTie_diancitie_PIN                                  (DL_GPIO_PIN_0)
#define DianCiTie_diancitie_IOMUX                                (IOMUX_PINCM12)
/* Port definition for Pin Group LED */
#define LED_PORT                                                         (GPIOB)

/* Defines for led: GPIOB.1 with pinCMx 13 on package pin 48 */
#define LED_led_PIN                                              (DL_GPIO_PIN_1)
#define LED_led_IOMUX                                            (IOMUX_PINCM13)
/* Port definition for Pin Group Motor_Ender */
#define Motor_Ender_PORT                                                 (GPIOB)

/* Defines for Motor_RIGHT_A: GPIOB.22 with pinCMx 50 on package pin 21 */
// pins affected by this interrupt request:["Motor_RIGHT_A","Motor_LEFT_A"]
#define Motor_Ender_INT_IRQN                                    (GPIOB_INT_IRQn)
#define Motor_Ender_INT_IIDX                    (DL_INTERRUPT_GROUP1_IIDX_GPIOB)
#define Motor_Ender_Motor_RIGHT_A_IIDX                      (DL_GPIO_IIDX_DIO22)
#define Motor_Ender_Motor_RIGHT_A_PIN                           (DL_GPIO_PIN_22)
#define Motor_Ender_Motor_RIGHT_A_IOMUX                          (IOMUX_PINCM50)
/* Defines for Motor_RIGHT_B: GPIOB.21 with pinCMx 49 on package pin 20 */
#define Motor_Ender_Motor_RIGHT_B_PIN                           (DL_GPIO_PIN_21)
#define Motor_Ender_Motor_RIGHT_B_IOMUX                          (IOMUX_PINCM49)
/* Defines for Motor_LEFT_A: GPIOB.20 with pinCMx 48 on package pin 19 */
#define Motor_Ender_Motor_LEFT_A_IIDX                       (DL_GPIO_IIDX_DIO20)
#define Motor_Ender_Motor_LEFT_A_PIN                            (DL_GPIO_PIN_20)
#define Motor_Ender_Motor_LEFT_A_IOMUX                           (IOMUX_PINCM48)
/* Defines for Motor_LEFT_B: GPIOB.24 with pinCMx 52 on package pin 23 */
#define Motor_Ender_Motor_LEFT_B_PIN                            (DL_GPIO_PIN_24)
#define Motor_Ender_Motor_LEFT_B_IOMUX                           (IOMUX_PINCM52)
/* Port definition for Pin Group Motor_Pin */
#define Motor_Pin_PORT                                                   (GPIOB)

/* Defines for RIGHT_Pin1: GPIOB.9 with pinCMx 26 on package pin 61 */
#define Motor_Pin_RIGHT_Pin1_PIN                                 (DL_GPIO_PIN_9)
#define Motor_Pin_RIGHT_Pin1_IOMUX                               (IOMUX_PINCM26)
/* Defines for RIGHT_Pin2: GPIOB.7 with pinCMx 24 on package pin 59 */
#define Motor_Pin_RIGHT_Pin2_PIN                                 (DL_GPIO_PIN_7)
#define Motor_Pin_RIGHT_Pin2_IOMUX                               (IOMUX_PINCM24)
/* Defines for LEFT_Pin2: GPIOB.23 with pinCMx 51 on package pin 22 */
#define Motor_Pin_LEFT_Pin2_PIN                                 (DL_GPIO_PIN_23)
#define Motor_Pin_LEFT_Pin2_IOMUX                                (IOMUX_PINCM51)
/* Defines for LEFT_Pin1: GPIOB.8 with pinCMx 25 on package pin 60 */
#define Motor_Pin_LEFT_Pin1_PIN                                  (DL_GPIO_PIN_8)
#define Motor_Pin_LEFT_Pin1_IOMUX                                (IOMUX_PINCM25)
/* Port definition for Pin Group Key */
#define Key_PORT                                                         (GPIOA)

/* Defines for Start_Key: GPIOA.16 with pinCMx 38 on package pin 9 */
// groups represented: ["WuXian","Key"]
// pins affected: ["IRQ","Start_Key","Mode_Change_key"]
#define GPIO_MULTIPLE_GPIOA_INT_IRQN                            (GPIOA_INT_IRQn)
#define GPIO_MULTIPLE_GPIOA_INT_IIDX            (DL_INTERRUPT_GROUP1_IIDX_GPIOA)
#define Key_Start_Key_IIDX                                  (DL_GPIO_IIDX_DIO16)
#define Key_Start_Key_PIN                                       (DL_GPIO_PIN_16)
#define Key_Start_Key_IOMUX                                      (IOMUX_PINCM38)
/* Defines for Mode_Change_key: GPIOA.30 with pinCMx 5 on package pin 37 */
#define Key_Mode_Change_key_IIDX                            (DL_GPIO_IIDX_DIO30)
#define Key_Mode_Change_key_PIN                                 (DL_GPIO_PIN_30)
#define Key_Mode_Change_key_IOMUX                                 (IOMUX_PINCM5)
/* Port definition for Pin Group line_sensor */
#define line_sensor_PORT                                                 (GPIOA)

/* Defines for PIN_0: GPIOA.17 with pinCMx 39 on package pin 10 */
#define line_sensor_PIN_0_PIN                                   (DL_GPIO_PIN_17)
#define line_sensor_PIN_0_IOMUX                                  (IOMUX_PINCM39)
/* Defines for PIN_1: GPIOA.14 with pinCMx 36 on package pin 7 */
#define line_sensor_PIN_1_PIN                                   (DL_GPIO_PIN_14)
#define line_sensor_PIN_1_IOMUX                                  (IOMUX_PINCM36)
/* Defines for PIN_2: GPIOA.15 with pinCMx 37 on package pin 8 */
#define line_sensor_PIN_2_PIN                                   (DL_GPIO_PIN_15)
#define line_sensor_PIN_2_IOMUX                                  (IOMUX_PINCM37)
/* Defines for PIN_3: GPIOA.22 with pinCMx 47 on package pin 18 */
#define line_sensor_PIN_3_PIN                                   (DL_GPIO_PIN_22)
#define line_sensor_PIN_3_IOMUX                                  (IOMUX_PINCM47)
/* Defines for PIN_4: GPIOA.25 with pinCMx 55 on package pin 26 */
#define line_sensor_PIN_4_PIN                                   (DL_GPIO_PIN_25)
#define line_sensor_PIN_4_IOMUX                                  (IOMUX_PINCM55)
/* Defines for PIN_5: GPIOA.24 with pinCMx 54 on package pin 25 */
#define line_sensor_PIN_5_PIN                                   (DL_GPIO_PIN_24)
#define line_sensor_PIN_5_IOMUX                                  (IOMUX_PINCM54)
/* Defines for PIN_6: GPIOA.27 with pinCMx 60 on package pin 31 */
#define line_sensor_PIN_6_PIN                                   (DL_GPIO_PIN_27)
#define line_sensor_PIN_6_IOMUX                                  (IOMUX_PINCM60)
/* Defines for PIN_7: GPIOA.26 with pinCMx 59 on package pin 30 */
#define line_sensor_PIN_7_PIN                                   (DL_GPIO_PIN_26)
#define line_sensor_PIN_7_IOMUX                                  (IOMUX_PINCM59)
/* Defines for BMI088_ACC: GPIOA.29 with pinCMx 4 on package pin 36 */
#define BMI088_pin_BMI088_ACC_PORT                                       (GPIOA)
#define BMI088_pin_BMI088_ACC_PIN                               (DL_GPIO_PIN_29)
#define BMI088_pin_BMI088_ACC_IOMUX                               (IOMUX_PINCM4)
/* Defines for BMI088_GY: GPIOB.14 with pinCMx 31 on package pin 2 */
#define BMI088_pin_BMI088_GY_PORT                                        (GPIOB)
#define BMI088_pin_BMI088_GY_PIN                                (DL_GPIO_PIN_14)
#define BMI088_pin_BMI088_GY_IOMUX                               (IOMUX_PINCM31)
/* Defines for CE: GPIOA.28 with pinCMx 3 on package pin 35 */
#define WuXian_CE_PORT                                                   (GPIOA)
#define WuXian_CE_PIN                                           (DL_GPIO_PIN_28)
#define WuXian_CE_IOMUX                                           (IOMUX_PINCM3)
/* Defines for IRQ: GPIOA.31 with pinCMx 6 on package pin 39 */
#define WuXian_IRQ_PORT                                                  (GPIOA)
#define WuXian_IRQ_IIDX                                     (DL_GPIO_IIDX_DIO31)
#define WuXian_IRQ_PIN                                          (DL_GPIO_PIN_31)
#define WuXian_IRQ_IOMUX                                          (IOMUX_PINCM6)
/* Defines for WuXian_Cs: GPIOB.25 with pinCMx 56 on package pin 27 */
#define WuXian_WuXian_Cs_PORT                                            (GPIOB)
#define WuXian_WuXian_Cs_PIN                                    (DL_GPIO_PIN_25)
#define WuXian_WuXian_Cs_IOMUX                                   (IOMUX_PINCM56)

/* clang-format on */

void SYSCFG_DL_init(void);
void SYSCFG_DL_initPower(void);
void SYSCFG_DL_GPIO_init(void);
void SYSCFG_DL_SYSCTL_init(void);
void SYSCFG_DL_PWMa_init(void);
void SYSCFG_DL_Duoji_init(void);
void SYSCFG_DL_Xunji_task_init(void);
void SYSCFG_DL_Yuntai_task_init(void);
void SYSCFG_DL_OLED_init(void);
void SYSCFG_DL_vofa_uart_init(void);
void SYSCFG_DL_see_uart_init(void);
void SYSCFG_DL_Liangan_init(void);
void SYSCFG_DL_BMI088_init(void);
void SYSCFG_DL_DMA_init(void);


bool SYSCFG_DL_saveConfiguration(void);
bool SYSCFG_DL_restoreConfiguration(void);

#ifdef __cplusplus
}
#endif

#endif /* ti_msp_dl_config_h */
