#include "Common_hand.h"
#include <math.h>


/* 张大头42闭环步进 串口控制 (Emm_V5协议, 0x6B固定校验) */
/* 基于MSPM0G3507 DL_UART, 帧格式与官方Emm_V5.c一致 */

#define ZDT_ADDR      1       
#define ZDT_CHECKSUM  0x6B   

void ZDT_Send(uint8_t *frame, uint8_t len)
{
    uint8_t i;
    for (i = 0; i < len; i++)
    {
        DL_UART_transmitDataBlocking(Liangan_INST, frame[i]);
    }
}

/* 电机使能: 0xF3, 张大头电机上电后必须先使能才响应速度/位置命令 */
/* state: 1=使能 0=解除使能 */
void ZDT_Enable(uint8_t addr, uint8_t state, uint8_t sync)
{
    uint8_t frame[6];
    frame[0] = addr;
    frame[1] = 0xF3;
    frame[2] = 0xAB;                       /* 固定标志字节 */
    frame[3] = state ? 0x01 : 0x00;
    frame[4] = sync ? 0x01 : 0x00;
    frame[5] = ZDT_CHECKSUM;
    ZDT_Send(frame, 6);
}

/* 立即停止: 0xFE */
void ZDT_Stop(uint8_t addr, uint8_t sync)
{
    uint8_t frame[5];
    frame[0] = addr;
    frame[1] = 0xFE;
    frame[2] = 0x98;                       /* 固定标志字节 */
    frame[3] = sync ? 0x01 : 0x00;
    frame[4] = ZDT_CHECKSUM;
    ZDT_Send(frame, 5);
}


/* Emm_V5速度模式: addr|0xF6|dir|speed_H|speed_L|accel(1B)|sync|0x6B (8字节) */
void ZDT_Speed(uint8_t addr, uint8_t dir, uint16_t speed, uint8_t accel, uint8_t sync)
{
    uint8_t frame[8];
    frame[0] = addr;
    frame[1] = 0xF6;
    frame[2] = dir ? 0x01 : 0x00;          /* 方向: 0=CW, 非0=CCW */
    frame[3] = (uint8_t)(speed >> 8);       /* 速度高字节 */
    frame[4] = (uint8_t)(speed & 0xFF);     /* 速度低字节 */
    frame[5] = accel;                       /* 加速度: 0=直启, 范围0-255 */
    frame[6] = sync ? 0x01 : 0x00;          /* 多机同步 */
    frame[7] = ZDT_CHECKSUM;
    ZDT_Send(frame, 8);
}


/* Emm_V5位置模式: addr|0xFD|dir|speed_H|speed_L|accel(1B)|angle[4B]|absolute|sync|0x6B (13字节) */
void ZDT_Position(uint8_t addr, uint8_t dir, uint16_t speed, uint8_t accel,
                  uint32_t angle, uint8_t absolute, uint8_t sync)
{
    uint8_t frame[13];
    frame[0]  = addr;
    frame[1]  = 0xFD;
    frame[2]  = dir ? 0x01 : 0x00;         /* 方向 */
    frame[3]  = (uint8_t)(speed >> 8);      /* 速度高字节 */
    frame[4]  = (uint8_t)(speed & 0xFF);    /* 速度低字节 */
    frame[5]  = accel;                      /* 加速度(0=直启) */
    frame[6]  = (uint8_t)(angle >> 24);     /* 脉冲数高8位 */
    frame[7]  = (uint8_t)(angle >> 16);
    frame[8]  = (uint8_t)(angle >> 8);
    frame[9]  = (uint8_t)(angle & 0xFF);
    frame[10] = absolute ? 0x01 : 0x00;    /* 0=相对, 1=绝对 */
    frame[11] = sync ? 0x01 : 0x00;        /* 多机同步 */
    frame[12] = ZDT_CHECKSUM;
    ZDT_Send(frame, 13);
}

/* 将当前位置设为编码器零点: 0x93 */
void ZDT_SetZero(uint8_t addr, uint8_t sync)
{
    uint8_t frame[5];
    frame[0] = addr;
    frame[1] = 0x93;
    frame[2] = 0x88;
    frame[3] = sync ? 0x01 : 0x00;
    frame[4] = ZDT_CHECKSUM;
    ZDT_Send(frame, 5);
}

/* 解除堵转保护: 0x0E，堵转保护触发后必须调用此命令才能恢复 */
void ZDT_Reset_ClogPro(uint8_t addr)
{
    uint8_t frame[4];
    frame[0] = addr;
    frame[1] = 0x0E;
    frame[2] = 0x52;
    frame[3] = ZDT_CHECKSUM;
    ZDT_Send(frame, 4);
}

/* ===== 位置环控制 ===== */
/* Emm_V5 默认16细分, 200步/圈 × 16 = 3200脉冲/圈 */
#define MICRO_STEPS     256
#define PULSES_PER_REV  (200 * MICRO_STEPS)
#define DEG_TO_PULSE    (PULSES_PER_REV / 360.0f)

#define BEAM_MAX_ANGLE  60.0f   /* PID输出限幅: 电机最大偏转角度(度) */
#define BEAM_MOVE_SPD   200     /* 电机到达目标位置的速度(RPM), 越高响应越快 */
#define NO_SEE_TIMEOUT  10      /* 100ms无视觉数据则回零 */

void Liangan_Init(void)
{
		/* PID输出 = 电机目标角度(度), 不再是速度 */
		/*          Kp     Ki     Kd       i_max    out_max(度) */
		PID_Init(&Liangan_pid, 13.5f, 0.5f, 150.0f, 5.0f, BEAM_MAX_ANGLE);
		Liangan_pid.deadzone = 0.0f;

		ZDT_Reset_ClogPro(ZDT_ADDR);
		Delay_ms(50);
		ZDT_Enable(ZDT_ADDR, 1, 0);
		Delay_ms(100);
		ZDT_SetZero(ZDT_ADDR, 0);
		Delay_ms(100);
}

static int32_t last_pulses = 0;
static uint8_t no_see_cnt = 0;
static float last_error = 0.0f;
static float ball_vel = 0.0f;
static float integral = 0.0f;

/* ========== 调参区 ========== */
#define KP          -30.0f  /* 推力 */
#define KD          -5.0f   /* 刹车 */
#define KI          -1.0f   /* 积分 */
#define KI_MAX      10.0f   /* 积分限幅(度) */
#define OVER_THRESH  0.95f   /* 超限阈值(cm) */
#define OVER_GAIN    15.0f  /* 超限额外补偿增益 */
#define DEAD_ZONE   0.5f   /* 到位死区(cm), 缩小减少静差 */
#define VEL_DEAD    1.0f    /* 速度死区(cm/s) */
#define KA_ACCEL   30.0f   /* 小车加速补偿 */
#define ACCEL_DEAD  0.15f   /* 加速度死区(m/s²), 滤掉振动 */
#define PULSE_DEADBAND 60   /* 脉冲死区, 缩小允许精细调整 */

void Liangan_ResetD(void)
{
		ball_vel = 0.0f;
		last_error = see_error;
}

void Liangan_task(void)
{
		if(see_flag == 0)
		{
				no_see_cnt++;
				if(no_see_cnt >= NO_SEE_TIMEOUT && last_pulses != 0)
				{
						ZDT_Position(ZDT_ADDR, 0, BEAM_MOVE_SPD, 0, 0, 1, 0);
						last_pulses = 0;
				}
				return;
		}
		see_flag = 0;
		no_see_cnt = 0;

		/* 1. 位置误差(cm), 正=球在目标右侧 */
		float err = see_error;

		/* 2. 球速(cm/s), 正=球往右跑 */
		float raw_vel = (err - last_error) * 100.0f;
		last_error = err;
		ball_vel = 0.4f * raw_vel + 0.6f * ball_vel;

		float abs_err = fabs(err);
		float abs_vel = fabs(ball_vel);

		float out;

		/* 3. Normal/Renyi模式: 到位锁杆, 停积分 */
		if(abs_err < DEAD_ZONE && abs_vel < VEL_DEAD
		   && (xunji_mode == XunJi_Mode_Nomal || xunji_mode == XunJi_Mode_Renyi))
		{
				integral = 0.0f;
				return;
		}
		else
		{
				/* 积分: 只在球慢时累积, 过零清除 */
				if(err * last_error < 0 && abs_err > DEAD_ZONE)
						integral = 0.0f;
				else if(abs_vel < 3.0f)
						integral += err;
				if(integral > KI_MAX) integral = KI_MAX;
				if(integral < -KI_MAX) integral = -KI_MAX;

				/* P: 推向目标 */
				float push = KP * err;

				/* D: 反向刹车 */
				float brake = KD * ball_vel;

				out = push + brake + KI * integral;
		}

		/* 超限补偿: 误差超过阈值时加大推力 */
		if(abs_err > OVER_THRESH)
		{
				float over = abs_err - OVER_THRESH;
				out += KP * over * (err > 0 ? 1.0f : -1.0f);
				integral = 0.0f;
		}

		/* 小车加速度前馈补偿, Normal/Renyi不补偿(车静止或匀速) */
		if(xunji_mode != XunJi_Mode_Nomal && xunji_mode != XunJi_Mode_Renyi)
		{
				float accel_comp = Accel_Forward;
				if(fabs(accel_comp) < ACCEL_DEAD) accel_comp = 0.0f;
				out += KA_ACCEL * accel_comp;
		}


		/* 限幅 */
		if(out > BEAM_MAX_ANGLE) out = BEAM_MAX_ANGLE;
		if(out < -BEAM_MAX_ANGLE) out = -BEAM_MAX_ANGLE;
		Liangan_pid.out = out;

		/* 发送到电机 */
		int32_t pulses = (int32_t)(out * DEG_TO_PULSE);

		int32_t diff = pulses - last_pulses;
		if(diff < 0) diff = -diff;
		if(diff < PULSE_DEADBAND)
				return;

		uint8_t  dir;
		uint32_t abs_pulses;
		if(pulses >= 0)
		{
				dir = 1;
				abs_pulses = (uint32_t)pulses;
		}
		else
		{
				dir = 0;
				abs_pulses = (uint32_t)(-pulses);
		}

		ZDT_Position(ZDT_ADDR, dir, BEAM_MOVE_SPD, 0, abs_pulses, 1, 0);
		last_pulses = pulses;
}