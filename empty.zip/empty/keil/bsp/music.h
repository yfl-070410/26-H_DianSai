#ifndef MUSIC_H
#define MUSIC_H

#include "ti_msp_dl_config.h"

void Music_open();

void Music_close();
#endif