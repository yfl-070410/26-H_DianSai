#include "Common_hand.h"

XunJi_state xunji_state;

extern PID line_sensor;

static GPIO_Regs* port[8] = {GPIOA, GPIOA, GPIOA, GPIOA, GPIOA, GPIOA, GPIOA, GPIOA};
static uint32_t   pin[8]  = {DL_GPIO_PIN_26, DL_GPIO_PIN_27, DL_GPIO_PIN_24, DL_GPIO_PIN_25,
                             DL_GPIO_PIN_22, DL_GPIO_PIN_15, DL_GPIO_PIN_14, DL_GPIO_PIN_17};

static const IOMUX_PINCM pincm[8] = {
    IOMUX_PINCM59,  /* PA26 */
    IOMUX_PINCM60,  /* PA27 */
    IOMUX_PINCM54,  /* PA24 */
    IOMUX_PINCM55,  /* PA25 */
    IOMUX_PINCM47,  /* PA22 */
    IOMUX_PINCM37,  /* PA15 */
    IOMUX_PINCM36,  /* PA14 */
    IOMUX_PINCM39,  /* PA17 */
};

static const float weight[8] = {-3.5f, -2.55f, -1.5f, -0.55f, 0.55f, 1.5f, 2.55f, 3.5f};

void line_init(void)
{
    for (int i = 0; i < 8; i++)
    {
        DL_GPIO_initDigitalInputFeatures(pincm[i],
            DL_GPIO_INVERSION_DISABLE, DL_GPIO_RESISTOR_PULL_UP,
            DL_GPIO_HYSTERESIS_DISABLE, DL_GPIO_WAKEUP_DISABLE);
    }
		PID_Init(&line_sensor, 0.155f, 0.0f, 0.8f, 0.0f, 0.65f);
		
		xunji_state=Xunji_open;
}


float line_get_error(void)
{
    uint8_t state = 0;
    for (int i = 0; i < 8; i++)
    {
        uint32_t val = DL_GPIO_readPins(port[i], pin[i]);

#if LINE_ACTIVE_LOW
        if (val == 0) state |= (1 << i);
#else
        if (val != 0) state |= (1 << i);
#endif
    }

    float sum = 0.0f;
    int   cnt = 0;
    for (int i = 0; i < 8; i++)
    {
        if (state & (1 << i))
        {
            sum += weight[i];
            cnt++;
        }
    }
    return (cnt > 0) ? (sum / cnt) : 0.0f;
}


LuoKou_state line_get_LuKou(void)
{
    uint8_t state = 0;
    for (int i = 0; i < 8; i++)
    {
        uint32_t val = DL_GPIO_readPins(port[i], pin[i]);

#if LINE_ACTIVE_LOW
        if (val == 0) state |= (1 << i);
#else
        if (val != 0) state |= (1 << i);
#endif
    }
		
		uint8_t right3 = (state & (1<<1)) && (state & (1<<2)) ;
		uint8_t left3  = (state & (1<<6)) && (state & (1<<5)) ;
		uint8_t mid    = (state & (1<<3)) && (state & (1<<4));

		uint8_t total = 0;
		for(int i = 0; i < 8; i++)
		{
				if(state & (1 << i)) total++;
		}

		if((state & (1<<2)) &&(state & (1<<5)) && mid &&((state & (1<<1)) ||(state & (1<<6))||(state & (1<<0))||(state & (1<<7))))
		{
				return LuoKou_all_black;
		}

		else
		{
				return LuoKou_Nomal;
		}
		
}
