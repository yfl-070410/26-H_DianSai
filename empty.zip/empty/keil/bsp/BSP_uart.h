#ifndef BSP_UART_H
#define BSP_UART_H

#include "ti_msp_dl_config.h"

void uart_send_byte(UART_Regs *uart,uint8_t b);

void uart_send_string(UART_Regs *uart,const char *str);

 
#endif
