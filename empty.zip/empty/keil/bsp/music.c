#include "Common_hand.h"

void Music_open()
{
		DL_GPIO_setPins(Music_PORT,Music_music_PIN);
}

void Music_close()
{
		DL_GPIO_clearPins(Music_PORT,Music_music_PIN);
}
