#ifndef SEE_UART_H
#define SEE_UART_H

#include "Common_hand.h"


void See_Uart_ready();
	
void See_Uart_Init();

extern volatile uint8_t see_flag;
extern float see_error;
extern uint8_t see_buf[7];
extern PID See_turn;

#endif