#include "Common_hand.h"


/* ���͵��ֽ� */
void uart_send_byte(UART_Regs *uart,uint8_t b)
{
		DL_UART_transmitDataBlocking(uart , b);
}

void uart_send_DATA(UART_Regs *uart,uint8_t*b,uint8_t len)
{
		for(uint8_t count=0;count<len;count++)
		{
				DL_UART_transmitDataBlocking(uart , b[count]);
		}

}

/* �����ַ��� */
void uart_send_string(UART_Regs *uart,const char *str)
{
    while (*str) {
        uart_send_byte(uart,(uint8_t)*str);
        str++;
    }
}
