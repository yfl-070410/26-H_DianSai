#ifndef PID_H
#define PID_H

#include "ti_msp_dl_config.h"


#define PID_TIM 0.01f


 typedef struct PID{
    float P,I,D;

    float error ,last_error;

    float integral;

    volatile int32_t count;        
		
    int32_t last_count,change_count;

    float traget, feedback;

    float i_max, out_max;

    float deadzone;

    float out;

 } PID;

 
extern PID Line_senor;
extern PID Liangan_pid;
extern PID distance;
 
void PID_Init(PID *pid,float kp,float ki,float kd,float i_max,float out_max);

float PID_Speed_Clac(PID *pid);

float PID_Angle_Clac(PID *pid);
 
float PID_Distance_Clac(PID *pid);

float PID_Clac(PID *pid,float trg,float feedback);
 
 #endif