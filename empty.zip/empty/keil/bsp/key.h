#ifndef KEY_H
#define KEY_H

#include "Common_hand.h"

void Key_Init();
	
#endif
