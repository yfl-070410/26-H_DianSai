#ifndef LIANGAN_H
#define LIANGAN_H

#include "Common_hand.h"

void ZDT_Send(uint8_t *frame, uint8_t len);

void ZDT_Enable(uint8_t addr, uint8_t state, uint8_t sync);

void ZDT_Stop(uint8_t addr, uint8_t sync);

void ZDT_SetZero(uint8_t addr, uint8_t sync);

void ZDT_Reset_ClogPro(uint8_t addr);

void ZDT_Speed(uint8_t addr, uint8_t dir, uint16_t speed, uint8_t accel, uint8_t sync);

void ZDT_Position(uint8_t addr, uint8_t dir, uint16_t speed, uint8_t accel,
                  uint32_t angle, uint8_t absolute, uint8_t sync);

void Liangan_Init(void);
void Liangan_task(void);
void Liangan_ResetD(void);
#endif