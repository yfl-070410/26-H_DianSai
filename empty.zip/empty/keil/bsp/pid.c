#include "Common_hand.h"      

extern Motor Left;                   
extern Motor Right;
PID line_sensor;

PID Liangan_pid;

PID distance;

void PID_Init(PID *pid,float kp,float ki,float kd,float i_max,float out_max)
{
    pid->P=kp;
    pid->I=ki;
    pid->D=kd;

    pid->i_max=i_max;
    pid->out_max=out_max;

    pid->integral=0;
    pid->error=0;
    pid->last_error=0;
    pid->count=0;
    pid->last_count=0;
    pid->change_count=0;
    pid->feedback=0;
    pid->out=0;
    pid->deadzone=0;
}


float PID_Speed_Clac(PID *pid)
{
		int32_t num= pid->count;
    pid->change_count = num - pid->last_count;
    pid->last_count  = num;

    if (pid->change_count > 32767)
        pid->change_count -= 65536;
    if (pid->change_count < -32767)
        pid->change_count += 65536;


    float raw_fb = (float)pid->change_count / (mg513_ppr * 1.0f * mg513_RATIO) * 2.0f * PI * R_Lun / PID_TIM;

    pid->feedback = 0.6f * raw_fb + 0.4f * pid->feedback;

    pid->error = pid->traget - pid->feedback;

   
    pid->integral += pid->error;

    if (pid->integral > pid->i_max)
        pid->integral = pid->i_max;
    if (pid->integral < -pid->i_max)
        pid->integral = -pid->i_max;

    pid->out = (pid->P * pid->error)
             + (pid->I * pid->integral)
             + (pid->D * (pid->error - pid->last_error));

    if (pid->out > pid->out_max)
        pid->out = pid->out_max;
    if (pid->out < -pid->out_max)
        pid->out = -pid->out_max;

    pid->last_error = pid->error;

    return pid->out;
}

float PID_Angle_Clac(PID *pid)
{	
		pid->feedback=pid->count/(mg513_ppr*1.0f*mg513_RATIO)*360.0f;
		
		pid->error=pid->traget-pid->feedback;
		
		pid->integral+=pid->error;
	
		if(pid->integral>pid->i_max)
		{
			pid->integral=pid->i_max;
		}
		
		if(pid->integral< -pid->i_max)
		{
			pid->integral=-pid->i_max;
		}
		
		pid->out=(pid->P * pid->error) + (pid->I * pid->integral) + pid->D*(pid->error - pid->last_error);
		
		if(pid->out>pid->out_max)
		{
			pid->out=pid->out_max;
		}
		
		if(pid->out< -pid->out_max)
		{
			pid->out=-pid->out_max;
		}
		
		pid->last_error=pid->error;
		
    return pid->out;
}

float PID_Distance_Clac(PID *pid)
{
		pid->feedback=pid->count/(mg513_ppr*1.0f*mg513_RATIO)*2*PI*R_Lun;
		
		pid->error=pid->traget-pid->feedback;
		
		pid->integral+=pid->error;
	
		if(pid->integral>pid->i_max)
		{
			pid->integral=pid->i_max;
		}
		
		if(pid->integral< -pid->i_max)
		{
			pid->integral=-pid->i_max;
		}
		
		pid->out=(pid->P * pid->error) + (pid->I * pid->integral) + pid->D*(pid->error - pid->last_error);
		
		if(pid->out>pid->out_max)
		{
			pid->out=pid->out_max;
		}
		
		if(pid->out< -pid->out_max)
		{
			pid->out=-pid->out_max;
		}
		
		pid->last_error=pid->error;
		
    return pid->out;
	
}

float PID_Clac(PID *pid,float trl ,float feedback)
{
		pid->traget=trl;

		pid->feedback=feedback;

		pid->error=pid->traget-pid->feedback;

		if(pid->deadzone > 0 && fabs(pid->error) < pid->deadzone)
		{
			pid->error=0;
			pid->integral=0;
			pid->out=0;
			pid->last_error=0;
			return 0;
		}

		pid->integral = pid->integral * 0.25f + pid->error;

		if(pid->integral>pid->i_max)
		{
			pid->integral=pid->i_max;
		}

		if(pid->integral< -pid->i_max)
		{
			pid->integral=-pid->i_max;
		}

		pid->out=(pid->P * pid->error) + (pid->I * pid->integral) + pid->D*(pid->error - pid->last_error);

		if(pid->out>pid->out_max)
		{
			pid->out=pid->out_max;
		}

		if(pid->out< -pid->out_max)
		{
			pid->out=-pid->out_max;
		}

		pid->last_error=pid->error;

		return pid->out;

}