#ifndef MOTOR_H
#define MOTOR_H

#include "ti_msp_dl_config.h"
#include "PID.h"


#define ENC_ALL_PINS  (Motor_Ender_Motor_LEFT_A_PIN  | Motor_Ender_Motor_LEFT_B_PIN  | \
                       Motor_Ender_Motor_RIGHT_A_PIN | Motor_Ender_Motor_RIGHT_B_PIN)


#define mg513_RATIO  28.0f

#define mg513_ppr 13.0f

#define R_Lun (0.065f/2.0f)

#define PI 3.1415926f


typedef enum motor_state {
    MOTOR_STOP,
    MOTOR_F,
    MOTOR_B
} motor_state;


typedef enum encoder_dir {
    ENC_DIR_NONE = 0,
    ENC_DIR_FWD  = 1,
    ENC_DIR_REV  = -1
} encoder_dir;


typedef struct Motor {
    PID pid;
    GPIO_Regs *pin;
    uint32_t pin1;
    uint32_t pin2;
    DL_TIMER_CC_INDEX channel;
    motor_state state;
    int8_t enc_dir;  
} Motor;

extern Motor Left;
extern Motor Right;  

void Motor_Init(Motor *motor, float kp, float ki, float kd, float i_max, float out_max,
                GPIO_Regs *pin, uint32_t pin1, uint32_t pin2, DL_TIMER_CC_INDEX channel,
                int8_t enc_dir);


void Encoder_Init(void);
void Encoder_Start(void);

void Motor_dir(Motor *motor);

void Motor_Stop(void);

void Motor_Brake(void);

void Motor_PID_Reset(void);

#endif
