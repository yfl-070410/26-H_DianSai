#include "Common_hand.h"

extern volatile uint8_t Car_start_flag;
Motor Left;
Motor Right;

/* 电机初始化：配置PID参数、方向引脚、PWM通道、编码器方向 */
void Motor_Init(Motor *motor, float kp, float ki, float kd, float i_max, float out_max,
                GPIO_Regs *pin, uint32_t pin1, uint32_t pin2, DL_TIMER_CC_INDEX channel,
                int8_t enc_dir)
{
    /* 初始化速度PID控制器 */
    PID_Init(&motor->pid, kp, ki, kd, i_max, out_max);

    /* 配置方向控制引脚：pin1正转, pin2反转 */
    motor->pin     = pin;
    motor->pin1    = pin1;
    motor->pin2    = pin2;

    /* 配置PWM输出通道 */
    motor->channel = channel;

    /* 编码器方向：1=正向, -1=反向 */
    motor->enc_dir = enc_dir;

    /* 初始状态：停止 */
    motor->state = MOTOR_STOP;
}

/* 编码器初始化：使能迟滞去抖，清零计数，启动中断 */
void Encoder_Init(void)
{
    DL_GPIO_clearInterruptStatus(Motor_Ender_PORT, ENC_ALL_PINS);

    /* 手动使能IO迟滞，防止编码器信号抖动 */
    IOMUX->SECCFG.PINCM[Motor_Ender_Motor_LEFT_A_IOMUX]  |= IOMUX_PINCM_HYSTEN_MASK;
    IOMUX->SECCFG.PINCM[Motor_Ender_Motor_LEFT_B_IOMUX]  |= IOMUX_PINCM_HYSTEN_MASK;
    IOMUX->SECCFG.PINCM[Motor_Ender_Motor_RIGHT_A_IOMUX] |= IOMUX_PINCM_HYSTEN_MASK;
    IOMUX->SECCFG.PINCM[Motor_Ender_Motor_RIGHT_B_IOMUX] |= IOMUX_PINCM_HYSTEN_MASK;

    Left.pid.count  = 0;
    Right.pid.count = 0;

    Encoder_Start();
}

/* 启动编码器中断 */
void Encoder_Start(void)
{
    NVIC_EnableIRQ(Motor_Ender_INT_IRQN);
}

/* 编码器中断：A相仅上升沿触发，读B相判方向（1倍频）
   A上升沿时 B=0→正转，B=1→反转（标准正交编码） */
void GROUP1_IRQHandler(void)
{
    uint32_t intflag = DL_Interrupt_getPendingGroup(DL_INTERRUPT_GROUP_1);

    if (intflag == Motor_Ender_INT_IIDX)
    {
        uint32_t status = DL_GPIO_getEnabledInterruptStatus(GPIOB, ENC_ALL_PINS);

        if (status & Motor_Ender_Motor_LEFT_A_PIN)
        {
            uint8_t b = (DL_GPIO_readPins(Motor_Ender_PORT, Motor_Ender_Motor_LEFT_B_PIN) != 0) ? 1 : 0;
            Left.pid.count += (b ? -1 : 1) * Left.enc_dir;
        }

        if (status & Motor_Ender_Motor_RIGHT_A_PIN)
        {
            uint8_t b = (DL_GPIO_readPins(Motor_Ender_PORT, Motor_Ender_Motor_RIGHT_B_PIN) != 0) ? 1 : 0;
            Right.pid.count += (b ? -1 : 1) * Right.enc_dir;
        }

				
        DL_GPIO_clearInterruptStatus(Motor_Ender_PORT, ENC_ALL_PINS);
    }
		
		if(intflag == GPIO_MULTIPLE_GPIOA_INT_IIDX)
		{
				uint32_t status = DL_GPIO_getEnabledInterruptStatus(GPIOA, Key_Start_Key_PIN |Key_Mode_Change_key_PIN);
				if (status & Key_Start_Key_PIN)
				{
						Car_start_flag = 1;
						DL_GPIO_clearInterruptStatus(GPIOA, Key_Start_Key_PIN);
				}
				else if(status & Key_Mode_Change_key_PIN)
				{
						if(mode_num==4)
						{
								mode_num=0;
						}
						else
						{
								mode_num++;
						}
						OLED_Clear();
						DL_GPIO_clearInterruptStatus(GPIOA, Key_Mode_Change_key_PIN);
				}

		}
}

/* 电机方向+速度输出：根据PID输出控制TB6612方向引脚和PWM占空比 */
void Motor_dir(Motor *motor) 
{
	if(motor->pid.out>0)
	{
		DL_GPIO_setPins(motor->pin,motor->pin1);
		DL_GPIO_clearPins(motor->pin,motor->pin2);
		DL_Timer_setCaptureCompareValue(PWMa_INST, motor->pid.out,motor->channel );
	}
	
	else if(motor->pid.out<0)
	{
		DL_GPIO_setPins(motor->pin,motor->pin2);
		DL_GPIO_clearPins(motor->pin,motor->pin1);
		DL_Timer_setCaptureCompareValue(PWMa_INST, -motor->pid.out,motor->channel );
	}
	
	else
	{
		DL_GPIO_clearPins(motor->pin,motor->pin2);
		DL_GPIO_clearPins(motor->pin,motor->pin1);
		DL_Timer_setCaptureCompareValue(PWMa_INST, 0,motor->channel );
		
	}
	
}

void Motor_Stop(void)
{
		Left.pid.traget = 0;
		Left.pid.integral = 0;
		Left.pid.out = 0;
		Right.pid.traget = 0;
		Right.pid.integral = 0;
		Right.pid.out = 0;

		DL_GPIO_clearPins(Left.pin, Left.pin1 | Left.pin2);
		DL_GPIO_clearPins(Right.pin, Right.pin1 | Right.pin2);
		DL_Timer_setCaptureCompareValue(PWMa_INST, 0, Left.channel);
		DL_Timer_setCaptureCompareValue(PWMa_INST, 0, Right.channel);
}

/* TB6612刹车: IN1=1 IN2=1 → 电机端子短路, 电磁制动, 快速停车 */
void Motor_Brake(void)
{
		Left.pid.traget = 0;
		Left.pid.integral = 0;
		Left.pid.out = 0;
		Right.pid.traget = 0;
		Right.pid.integral = 0;
		Right.pid.out = 0;

		DL_GPIO_setPins(Left.pin, Left.pin1 | Left.pin2);
		DL_GPIO_setPins(Right.pin, Right.pin1 | Right.pin2);
		DL_Timer_setCaptureCompareValue(PWMa_INST, 0, Left.channel);
		DL_Timer_setCaptureCompareValue(PWMa_INST, 0, Right.channel);
}

void Motor_PID_Reset(void)
{
    Left.pid.integral = 0.0f;
    Right.pid.integral = 0.0f;
	
    Left.pid.last_count =0;
		Left.pid.count=0;
    Right.pid.last_count =0; 
		Right.pid.count=0;

		Left.pid.change_count = 0;
    Right.pid.change_count = 0;

    Left.pid.feedback = 0.0f;
    Right.pid.feedback = 0.0f;

    Left.pid.out = 0.0f;
    Right.pid.out = 0.0f;
}