#include "Common_hand.h"

void Key_Init()
{
		NVIC_EnableIRQ(GPIO_MULTIPLE_GPIOA_INT_IRQN);
}

