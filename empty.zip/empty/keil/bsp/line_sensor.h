#ifndef __LINE_SENSOR_H
#define __LINE_SENSOR_H

#include "ti_msp_dl_config.h"
#include "PID.h"

// ��⵽����ʱ����������͵�ƽ(0)���� 1
#define LINE_ACTIVE_LOW  0

typedef enum LuoKou_state
{
		LuoKou_Nomal=0,
		LuoKou_left_Zhijiao=1,
		LuoKou_right_Zhijiao=2,
		LuoKou_left_Ruijiao=3,
		LuoKou_right_Ruijiao=4,
		LuoKou_all_black=5,
		LuoKou_all_white=6,
}LuoKou_state;

typedef enum Xunji_state
{
		Xunji_open,
		Xunji_close,
}XunJi_state;

extern XunJi_state xunji_state;
extern PID line_sensor;

void line_init(void);

float line_get_error(void);

LuoKou_state line_get_LuKou(void);

#endif
