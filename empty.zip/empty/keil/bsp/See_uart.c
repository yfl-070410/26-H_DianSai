#include "Common_hand.h"

uint8_t see_buf[7]={0};
volatile uint8_t see_flag=0;
float see_error=0;

volatile float see_glod;

PID See_turn;

typedef enum {
    SEE_WAIT_HEAD,
    SEE_RECV_BODY
} See_State;

static volatile See_State see_state = SEE_WAIT_HEAD;

static void flush_see_fifo(void)
{
    while (!DL_UART_Main_isRXFIFOEmpty(see_uart_INST))
        (void)DL_UART_Main_receiveData(see_uart_INST);
}

static void DMA_recv(uint32_t dest, uint8_t len)
{
    DL_DMA_setSrcAddr(DMA, DMA_CH0_CHAN_ID, (uint32_t)(&see_uart_INST->RXDATA));
    DL_DMA_setDestAddr(DMA, DMA_CH0_CHAN_ID, dest);
    DL_DMA_setTransferSize(DMA, DMA_CH0_CHAN_ID, len);
    DL_DMA_enableChannel(DMA, DMA_CH0_CHAN_ID);
}

void See_Uart_ready()
{
    flush_see_fifo();
    see_state = SEE_WAIT_HEAD;
    DMA_recv((uint32_t)&see_buf[0], 1);
    NVIC_EnableIRQ(see_uart_INST_INT_IRQN);

    PID_Init(&See_turn,0.005f,0.0f,0.01f,0.0f,0.4);
}

void see_uart_INST_IRQHandler(void)
{
    switch (DL_UART_Main_getPendingInterrupt(see_uart_INST)) {
        case DL_UART_MAIN_IIDX_DMA_DONE_RX:
            if(see_state == SEE_WAIT_HEAD)
            {
                if(see_buf[0] == 0xAA)
                {
                    see_state = SEE_RECV_BODY;
                    DMA_recv((uint32_t)&see_buf[1], 4);
                }
                else
                {
                    DMA_recv((uint32_t)&see_buf[0], 1);
                }
            }
            else
            {
                if(see_buf[4] == 0xBB)
                {
                    if(see_buf[1] == 0x01)
                    {
                        see_error = (float)((int16_t)(see_buf[2]<<8
                                  | (see_buf[3]))) / 1000.0f;
                        see_flag = 1;
                    }
                }
                see_state = SEE_WAIT_HEAD;
                DMA_recv((uint32_t)&see_buf[0], 1);
            }
            break;
        default:
            break;
    }
}
