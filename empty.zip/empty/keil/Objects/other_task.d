./objects/other_task.o: task\Other_task.c
