#ifndef XUNJI_TASK_H
#define XUNJI_TASK_H

#include "ti_msp_dl_config.h"
#include "motor.h"
#include "line_sensor.h"



typedef enum XunJi_Mode{
		XunJi_Mode_Nomal=0,
		XunJi_Mode_Renyi,
		XunJi_Mode_Distance,
		XunJi_Mode_Nomal_30s,
		XunJi_Mode_Renyi_30s,
} XunJi_Mode;


void XunJi_Init();

void XunJi_Task_Nomal();

void XunJi_Task_Distance();

void XunJi_Disable(void);

void XunJi_Enable(void);

/* 运行时间变量 */
extern volatile uint16_t time_ms;
extern volatile uint8_t time_s;
extern volatile uint8_t time_m;
extern volatile uint8_t time_h;
extern volatile uint8_t time_display_flag;

extern volatile uint8_t distance_frist;

extern volatile uint8_t Renyi_frist;
extern volatile uint8_t mode_num;
extern XunJi_Mode xunji_mode;

#endif
