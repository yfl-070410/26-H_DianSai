#include "Common_hand.h"

float xunji_base_speed=0.4;

XunJi_Mode xunji_mode=XunJi_Mode_Nomal;

/* 直角后直行延时 */
static float zhijiao_distance = 0.05;
volatile uint8_t distance_frist=0;
static int32_t distance_start_count = 0;

volatile uint8_t Renyi_frist=0;
volatile uint8_t Nomal_frist=0;
volatile uint8_t Nomal_30=0;
volatile uint8_t Renyi_30=0;
volatile uint8_t mode_num=0;


uint8_t all_black_num=0;
static uint8_t in_all_black=1;  /* 起点在全黑线上，初始为1避免误计数 */
static uint8_t black_confirm=0; /* 连续全黑计数(消抖) */
#define BLACK_CONFIRM_N 3       /* Distance/30s需连续3次才认定全黑 */
static uint16_t grace_ticks=0;
#define GRACE_PERIOD 200        /* 起步保护: 2秒内不检测全黑停车 */
static uint8_t stop_phase=0;   /* 0=正常 1=反转中 2=已锁死 */
static uint8_t reverse_cnt=0;  /* 反转倒计时 */

#define BRAKE_SPEED    1.5f
#define REVERSE_TICKS  10 /* 反转持续 */

#define SLOW_BASE_SPEED  0.25f
#define DECEL_STEP       0.001f

static float slow_speed = 0;
static uint8_t slow_stopping = 0; /* 0=正常 1=减速中 2=已停 */

#define ACCEL_STEP  0.0004f
static float ramp_speed = 0.0f;
#define RAMP_START  0.06f

#define STEER_LIMIT  0.25f
#define STEER_MAX    0.1f
static float last_steer = 0.0f;

void XunJi_Init()
{
		Motor_Init(&Left, 1400.0f, 18.5f, 0.0f, 50.0f, 1600.0f,
								Motor_Pin_PORT,
								Motor_Pin_LEFT_Pin1_PIN,
								Motor_Pin_LEFT_Pin2_PIN,
								GPIO_PWMa_C1_IDX,
								-1);
		Motor_Init(&Right, 1400.0f, 18.5f, 0.0f, 50.0f, 1600.0f,
								Motor_Pin_PORT,
								Motor_Pin_RIGHT_Pin1_PIN,
								Motor_Pin_RIGHT_Pin2_PIN,
								GPIO_PWMa_C0_IDX,
								-1);

		PID_Init(&distance, 5.0f, 0.1f, 0.01f, 0.3f, 0.3f);

		Left.pid.traget  = xunji_base_speed ;
		Right.pid.traget = xunji_base_speed;

		Encoder_Init();

		line_init();

		DL_GPIO_setPins(tb66_stay_PORT,tb66_stay_tb66_stay_pin_PIN);

		DL_Timer_startCounter(PWMa_INST);
		DL_Timer_startCounter(Xunji_task_INST);
		NVIC_EnableIRQ(Xunji_task_INST_INT_IRQN);

}


void XunJi_Task_Nomal()
{
		float error=0;
		if(xunji_state==Xunji_open)
		{
				error=line_get_error();
				error = PID_Clac(&line_sensor, 0, error);
		}

		Left.pid.traget  = xunji_base_speed + error;
		Right.pid.traget =xunji_base_speed - error;

		PID_Speed_Clac(&Left.pid);
		PID_Speed_Clac(&Right.pid);

		Motor_dir(&Left);
		Motor_dir(&Right);

}

#define DIST_BASE_SPEED     0.3f   /* Distance模式巡航速度 */
#define DISTANCE_RUN_TIME   800     /* 定时停车: 10ms/tick, 800=8秒 */
static uint16_t distance_run_ticks = 0; /* Distance模式已运行tick数 */

void XunJi_Task_Distance()
{
		/* 线性加速到巡航速度 (同Nomal_30) */
		ramp_speed += ACCEL_STEP+0.0003;
		if(ramp_speed > DIST_BASE_SPEED) ramp_speed = DIST_BASE_SPEED;

		if(slow_stopping==0)
		{
				float error=0;
				if(xunji_state==Xunji_open && ramp_speed > 0.05f && grace_ticks >= GRACE_PERIOD)
				{
						error=line_get_error();
						error=PID_Clac(&line_sensor, 0, error);
				}
				/* 转向变化率限制, 防止急转侧翻 */
				if(error - last_steer > STEER_LIMIT) error = last_steer + STEER_LIMIT;
				if(error - last_steer < -STEER_LIMIT) error = last_steer - STEER_LIMIT;
				if(fabs(error) > ramp_speed * 0.5f)
						error = (error > 0 ? 1.0f : -1.0f) * ramp_speed * 0.5f;
				last_steer = error;

				Left.pid.traget  = ramp_speed + error;
				Right.pid.traget = ramp_speed - error;
				PID_Speed_Clac(&Left.pid);
				PID_Speed_Clac(&Right.pid);
				Motor_dir(&Left);
				Motor_dir(&Right);
		}
		else if(slow_stopping==1)
		{
				slow_speed -= DECEL_STEP;
				if(slow_speed <= 0)
				{
						slow_stopping=2;
						xunji_state=Xunji_close;
						Motor_PID_Reset();
						Motor_Stop();
						DL_GPIO_clearPins(tb66_stay_PORT, tb66_stay_tb66_stay_pin_PIN);
				}
				else
				{
						Left.pid.traget  = slow_speed;
						Right.pid.traget = slow_speed;
						PID_Speed_Clac(&Left.pid);
						PID_Speed_Clac(&Right.pid);
						Motor_dir(&Left);
						Motor_dir(&Right);
				}
		}
}

void XunJi_Disable(void)
{
      xunji_state = Xunji_close;

      Left.pid.integral = 0;
      Right.pid.integral = 0;
      line_sensor.integral = 0;

      Left.pid.traget = 0.0f;
      Right.pid.traget = 0.0f;
      Left.pid.out = 0.0f;
      Right.pid.out = 0.0f;
			Motor_PID_Reset();

      Motor_Stop();
}

void XunJi_Enable(void)
{
		xunji_mode = XunJi_Mode_Nomal;

		Left.pid.traget = xunji_base_speed;
		Right.pid.traget = xunji_base_speed;

		Left.pid.integral = 0;
		Right.pid.integral = 0;
		line_sensor.integral = 0;

		Motor_PID_Reset();
		xunji_state=Xunji_open;
}


volatile uint16_t time_ms = 0;
volatile uint8_t time_s = 0;
volatile uint8_t time_m = 0;
volatile uint8_t time_h = 0;
volatile uint8_t time_display_flag = 0;

static uint8_t display_tick = 0;
LuoKou_state lk=LuoKou_Nomal;

void Xunji_task_INST_IRQHandler()
{
		AHRS_Geteuler();
		Liangan_task();

		if(grace_ticks < GRACE_PERIOD) grace_ticks++;

		lk=line_get_LuKou();

		if(stop_phase==1)
		{
				/* 反转倒计时 */
				reverse_cnt--;
				if(reverse_cnt==0)
				{
						stop_phase=2;
						Motor_PID_Reset();
						Motor_Brake();
				}
				else
				{
						Left.pid.traget  = -BRAKE_SPEED;
						Right.pid.traget = -BRAKE_SPEED;
						PID_Speed_Clac(&Left.pid);
						PID_Speed_Clac(&Right.pid);
						Motor_dir(&Left);
						Motor_dir(&Right);
				}
		}
		else if(stop_phase==2)
		{
				/* 已锁死, 什么都不做 */
		}
		else
		{
		if(lk==LuoKou_Nomal)
		{
				in_all_black=0;
				black_confirm=0;

				if(xunji_mode==XunJi_Mode_Nomal)
				{
						if(Nomal_frist==0)
						{
								Nomal_frist=1;
								DL_UART_transmitDataBlocking(see_uart_INST , 0xAA);
						}
						XunJi_Task_Nomal();
				}
				else if(xunji_mode==XunJi_Mode_Renyi)
				{
						if(Renyi_frist==0)
						{
								Renyi_frist=1;
								DL_UART_transmitDataBlocking(see_uart_INST , 0xCC);
						}
						XunJi_Task_Nomal();
				}
				else if(xunji_mode==XunJi_Mode_Nomal_30s)
				{
						if(Nomal_30==0)
						{
								Nomal_30=1;
								ramp_speed=RAMP_START;
								last_steer=0.0f;
								slow_stopping=0;
								DL_UART_transmitDataBlocking(see_uart_INST , 0xBB);
						}
						ramp_speed += ACCEL_STEP;
						if(ramp_speed > SLOW_BASE_SPEED) ramp_speed = SLOW_BASE_SPEED;

						if(slow_stopping==0)
						{
								float error=0;
								if(xunji_state==Xunji_open && ramp_speed > 0.05f && grace_ticks >= GRACE_PERIOD)
								{
										error=line_get_error();
										error=PID_Clac(&line_sensor, 0, error);
								}
								if(error - last_steer > STEER_LIMIT) error = last_steer + STEER_LIMIT;
								if(error - last_steer < -STEER_LIMIT) error = last_steer - STEER_LIMIT;
								if(fabs(error) > ramp_speed * 0.5f)
										error = (error > 0 ? 1.0f : -1.0f) * ramp_speed * 0.5f;
								last_steer = error;
								Left.pid.traget  = ramp_speed + error;
								Right.pid.traget = ramp_speed - error;
								PID_Speed_Clac(&Left.pid);
								PID_Speed_Clac(&Right.pid);
								Motor_dir(&Left);
								Motor_dir(&Right);
						}
						else if(slow_stopping==1)
						{
								slow_speed -= DECEL_STEP;
								if(slow_speed <= 0)
								{
										slow_stopping=2;
										Motor_PID_Reset();
										Motor_Brake();
								}
								else
								{
										float error=0;
										if(xunji_state==Xunji_open)
										{
												error=line_get_error();
												error=PID_Clac(&line_sensor, 0, error);
										}
										if(fabs(error) > slow_speed * 0.5f)
												error = (error > 0 ? 1.0f : -1.0f) * slow_speed * 0.5f;
										Left.pid.traget  = slow_speed + error;
										Right.pid.traget = slow_speed - error;
										PID_Speed_Clac(&Left.pid);
										PID_Speed_Clac(&Right.pid);
										Motor_dir(&Left);
										Motor_dir(&Right);
								}
						}
				}
				else if(xunji_mode==XunJi_Mode_Renyi_30s)
				{
						if(Renyi_30==0)
						{
								Renyi_30=1;
								ramp_speed=RAMP_START;
								last_steer=0.0f;
								slow_stopping=0;
								DL_UART_transmitDataBlocking(see_uart_INST , 0xCC);
						}
						ramp_speed += ACCEL_STEP;
						if(ramp_speed > SLOW_BASE_SPEED) ramp_speed = SLOW_BASE_SPEED;

						if(slow_stopping==0)
						{
								float error=0;
								if(xunji_state==Xunji_open && ramp_speed > 0.05f && grace_ticks >= GRACE_PERIOD)
								{
										error=line_get_error();
										error=PID_Clac(&line_sensor, 0, error);
								}
								if(error - last_steer > STEER_LIMIT) error = last_steer + STEER_LIMIT;
								if(error - last_steer < -STEER_LIMIT) error = last_steer - STEER_LIMIT;
								if(fabs(error) > ramp_speed * 0.5f)
										error = (error > 0 ? 1.0f : -1.0f) * ramp_speed * 0.5f;
								last_steer = error;
								Left.pid.traget  = ramp_speed + error;
								Right.pid.traget = ramp_speed - error;
								PID_Speed_Clac(&Left.pid);
								PID_Speed_Clac(&Right.pid);
								Motor_dir(&Left);
								Motor_dir(&Right);
						}
						else if(slow_stopping==1)
						{
								slow_speed -= DECEL_STEP;
								if(slow_speed <= 0)
								{
										slow_stopping=2;
										Motor_PID_Reset();
										Motor_Brake();
								}
								else
								{
										float error=0;
										if(xunji_state==Xunji_open)
										{
												error=line_get_error();
												error=PID_Clac(&line_sensor, 0, error);
										}
										if(fabs(error) > slow_speed * 0.5f)
												error = (error > 0 ? 1.0f : -1.0f) * slow_speed * 0.5f;
										Left.pid.traget  = slow_speed + error;
										Right.pid.traget = slow_speed - error;
										PID_Speed_Clac(&Left.pid);
										PID_Speed_Clac(&Right.pid);
										Motor_dir(&Left);
										Motor_dir(&Right);
								}
						}
				}
				else if(xunji_mode==XunJi_Mode_Distance)
				{
						stop_phase = 0; /* 清除其他模式残留的停车锁死 */
						/* DEBUG: 抓取关键变量, 确认问题环节 */
						if(distance_frist==0)
						{
								distance_frist=1;
								ramp_speed=RAMP_START;
								last_steer=0.0f;
								slow_stopping=0;
								distance_run_ticks=0;
								DL_UART_transmitDataBlocking(see_uart_INST , 0xBB);
						}
						if(slow_stopping>=2)
						{
								/* 已停车, 不再驱动 */
						}
						else
						{
						xunji_state=Xunji_open;

						/* 8秒定时停车 */
						if(slow_stopping==0)
						{
								distance_run_ticks++;
								if(distance_run_ticks >= DISTANCE_RUN_TIME)
								{
										slow_stopping=1;
										slow_speed=ramp_speed;
								}
						}

						XunJi_Task_Distance();
						}
				}
		}
		else if(lk==LuoKou_all_black)
		{
				/* 边沿检测: 保护期内不计数, 防止起步边缘闪烁误触发 */
				if(in_all_black==0 && grace_ticks >= GRACE_PERIOD)
				{
						if(xunji_mode==XunJi_Mode_Distance || xunji_mode==XunJi_Mode_Nomal_30s
						   || xunji_mode==XunJi_Mode_Renyi_30s)
						{
								black_confirm++;
								if(black_confirm >= BLACK_CONFIRM_N)
								{
										in_all_black=1;
										all_black_num++;
								}
						}
						else
						{
								in_all_black=1;
								all_black_num++;
						}
				}

				if(all_black_num>=1)
				{
						if(xunji_mode==XunJi_Mode_Nomal_30s || xunji_mode==XunJi_Mode_Renyi_30s
						   || xunji_mode==XunJi_Mode_Distance)
						{
								if(slow_stopping==0)
								{
										slow_stopping=1;
										slow_speed=ramp_speed > 0.01f ? ramp_speed : SLOW_BASE_SPEED;
								}
						}
						else
						{
								stop_phase=1;
								reverse_cnt=REVERSE_TICKS;
								xunji_state=Xunji_close;
								Motor_PID_Reset();
						}
				}
				else
				{
						/* 第一段全黑: 直行通过 */
						if(xunji_mode==XunJi_Mode_Nomal_30s || xunji_mode==XunJi_Mode_Renyi_30s)
						{
								if(ramp_speed < RAMP_START) ramp_speed = RAMP_START;
								ramp_speed += ACCEL_STEP;
								if(ramp_speed > SLOW_BASE_SPEED) ramp_speed = SLOW_BASE_SPEED;
								Left.pid.traget  = ramp_speed;
								Right.pid.traget = ramp_speed;
						}
						else if(xunji_mode==XunJi_Mode_Distance)
						{
								if(ramp_speed < RAMP_START) ramp_speed = RAMP_START;
								ramp_speed += ACCEL_STEP+0.0003;
								if(ramp_speed > DIST_BASE_SPEED) ramp_speed = DIST_BASE_SPEED;
								Left.pid.traget  = ramp_speed;
								Right.pid.traget = ramp_speed;
								/* 计时器也在全黑段推进 */
								distance_run_ticks++;
								if(distance_run_ticks >= DISTANCE_RUN_TIME)
								{
										slow_stopping=1;
										slow_speed=ramp_speed;
								}
						}
						else
						{
								Left.pid.traget  = xunji_base_speed;
								Right.pid.traget = xunji_base_speed;
						}
						PID_Speed_Clac(&Left.pid);
						PID_Speed_Clac(&Right.pid);
						Motor_dir(&Left);
						Motor_dir(&Right);
				}
		}
		else
		{
				/* 路口/全白等状态: 维持直行, 避免电机失速 */
				if(xunji_mode==XunJi_Mode_Distance)
				{
						if(slow_stopping==0)
						{
								distance_run_ticks++;
								if(distance_run_ticks >= DISTANCE_RUN_TIME)
								{
										slow_stopping=1;
										slow_speed=ramp_speed;
								}
						}
						XunJi_Task_Distance();
				}
				else if(xunji_mode==XunJi_Mode_Nomal_30s || xunji_mode==XunJi_Mode_Renyi_30s)
				{
						ramp_speed += ACCEL_STEP;
						if(ramp_speed > SLOW_BASE_SPEED) ramp_speed = SLOW_BASE_SPEED;
						Left.pid.traget  = ramp_speed;
						Right.pid.traget = ramp_speed;
						PID_Speed_Clac(&Left.pid);
						PID_Speed_Clac(&Right.pid);
						Motor_dir(&Left);
						Motor_dir(&Right);
				}
				else if(xunji_mode==XunJi_Mode_Nomal || xunji_mode==XunJi_Mode_Renyi)
				{
						XunJi_Task_Nomal();
				}
		}
		}

		// 时间计数: 每10ms加一次
		if(stop_phase>=1 || slow_stopping>=1)
		{

		}
		else
		{
					time_ms += 10;
					if (time_ms >= 1000)
					{
							time_ms -= 1000;
							time_s++;
							if (time_s >= 60)
							{
									time_s = 0;
									time_m++;
									if (time_m >= 60)
									{
											time_m = 0;
											time_h++;
									}
							}
					}
					display_tick++;
					if (display_tick >= 10)
					{
							display_tick = 0;
							time_display_flag = 1;
					}
		}



		DL_Timer_clearInterruptStatus(Xunji_task_INST ,DL_TIMER_INTERRUPT_ZERO_EVENT);
}
