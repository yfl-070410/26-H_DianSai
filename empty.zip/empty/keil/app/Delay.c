#include "Common_hand.h"

void Delay_ms(uint16_t ms)
{
	if(ms>0)
	{
			delay_cycles(32000 * ms);
	}
	else{
			return;
	}
}

void Delay_s(uint16_t s)
{
	if(s>0)
	{
			delay_cycles(32000000 * s);
	}
	else{
			return;
	}
}