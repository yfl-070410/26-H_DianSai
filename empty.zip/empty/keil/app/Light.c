#include "Common_hand.h"

void Light_open()
{
		DL_GPIO_setPins(LED_PORT,LED_led_PIN);
}

void Light_close()
{
	  DL_GPIO_clearPins(LED_PORT,LED_led_PIN);
}
