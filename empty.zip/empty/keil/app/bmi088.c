/*
 * bmi088.c - BMI088 SPI驱动 + 互补滤波姿态解算
 */

#include "Common_hand.h"

/* ====================== SPI底层宏 ====================== */

#define SPI_READ_MASK     0x80U
#define SPI_WRITE_MASK    0x7FU
#define SPI_DUMMY         0x00U

/* 加速度计寄存器 */
#define ACC_REG_CHIP_ID   0x00U
#define ACC_REG_DATA      0x12U
#define ACC_REG_CONF      0x40U
#define ACC_REG_RANGE     0x41U
#define ACC_REG_PWR_CONF  0x7CU
#define ACC_REG_PWR_CTRL  0x7DU

/* 陀螺仪寄存器 */
#define GYRO_REG_DATA     0x02U
#define GYRO_REG_RANGE    0x0FU
#define GYRO_REG_BANDWIDTH 0x10U
#define GYRO_REG_LPM1     0x11U

/* 配置常量 */
#define ACC_CONF_800HZ    0xABU
#define ACC_RANGE_6G      0x01U
#define ACC_PWR_ACTIVE    0x00U
#define ACC_PWR_ON        0x04U
#define GYRO_RANGE_2000   0x00U
#define GYRO_BW_116HZ     0x02U
#define GYRO_LPM1_NORMAL  0x00U

/* ====================== 算法参数 ====================== */
#define ACC_SCALE_G       (6.0f / 32768.0f)
#define GYRO_SCALE_DPS    (2000.0f / 32768.0f)
#define DT                0.01f
#define COMP_ALPHA        0.98f
#define CAL_SAMPLES       100    /* 1秒校准 (100×10ms) */
#define LPF_ALPHA         0.15f
#define GYRO_DEADZONE     2.0f   /* 静止零漂死区 deg/s */
#define MS_TO_CYCLES(ms)  ((uint32_t)((CPUCLK_FREQ / 1000U) * (ms)))

/* ====================== 全局变量 ====================== */
BMI088_DEF bmi088;
float Gyro_Z_Measure = 0.0f;
float Gyro_Z_Raw = 0.0f;
float Accel_Forward = 0.0f;

/* ====================== 内部状态 ====================== */
static float bias_gx, bias_gy, bias_gz;
static float bias_ax;
static float sum_gx, sum_gy, sum_gz;
static float sum_ax;
static uint16_t cal_cnt;
static uint8_t cal_done;

static float flt_ax, flt_ay, flt_az;
static float flt_gx, flt_gy, flt_gz;
static uint8_t first_sample;

static float angle_roll, angle_pitch, angle_yaw;

/* ====================== 工具函数 ====================== */
static float lpf(float last, float in, float a) { return a * in + (1.0f - a) * last; }

/* ====================== SPI操作函数 ====================== */
static void delay_ms(uint32_t ms) { delay_cycles(MS_TO_CYCLES(ms)); }

static void acc_cs_lo(void)  { DL_GPIO_clearPins(BMI088_pin_BMI088_ACC_PORT, BMI088_pin_BMI088_ACC_PIN); }
static void acc_cs_hi(void)  { DL_GPIO_setPins(BMI088_pin_BMI088_ACC_PORT, BMI088_pin_BMI088_ACC_PIN); }
static void gy_cs_lo(void)   { DL_GPIO_clearPins(BMI088_pin_BMI088_GY_PORT, BMI088_pin_BMI088_GY_PIN); }
static void gy_cs_hi(void)   { DL_GPIO_setPins(BMI088_pin_BMI088_GY_PORT, BMI088_pin_BMI088_GY_PIN); }

static void flush_rx(void) {
    while (!DL_SPI_isRXFIFOEmpty(BMI088_INST))
        (void)DL_SPI_receiveData8(BMI088_INST);
}

static uint8_t spi_xfer(uint8_t d) {
    DL_SPI_transmitDataBlocking8(BMI088_INST, d);
    return DL_SPI_receiveDataBlocking8(BMI088_INST);
}

static void acc_read(uint8_t reg, uint8_t *buf, uint8_t len) {
    flush_rx(); acc_cs_lo();
    (void)spi_xfer(reg | SPI_READ_MASK);
    (void)spi_xfer(SPI_DUMMY);
    for (uint8_t i = 0; i < len; i++) buf[i] = spi_xfer(SPI_DUMMY);
    acc_cs_hi();
}

static void acc_write(uint8_t reg, uint8_t d) {
    flush_rx(); acc_cs_lo();
    (void)spi_xfer(reg & SPI_WRITE_MASK);
    (void)spi_xfer(d);
    acc_cs_hi();
    delay_cycles(CPUCLK_FREQ / 500000U);
}

static void gy_read(uint8_t reg, uint8_t *buf, uint8_t len) {
    flush_rx(); gy_cs_lo();
    (void)spi_xfer(reg | SPI_READ_MASK);
    for (uint8_t i = 0; i < len; i++) buf[i] = spi_xfer(SPI_DUMMY);
    gy_cs_hi();
}

static void gy_write(uint8_t reg, uint8_t d) {
    flush_rx(); gy_cs_lo();
    (void)spi_xfer(reg & SPI_WRITE_MASK);
    (void)spi_xfer(d);
    gy_cs_hi();
    delay_cycles(CPUCLK_FREQ / 500000U);
}

static int16_t get_i16(const uint8_t *d, uint8_t i) {
    return (int16_t)((uint16_t)d[i] | ((uint16_t)d[i+1] << 8));
}

/* ====================== 初始化 ====================== */
void bmi088_init(void)
{
    uint8_t dummy;
    acc_cs_hi(); gy_cs_hi();
    delay_ms(1);

    /* 加速度计 */
    acc_read(0x00, &dummy, 1);
    delay_ms(1);
    acc_write(ACC_REG_PWR_CTRL, ACC_PWR_ON);
    delay_ms(1);
    acc_write(ACC_REG_PWR_CONF, ACC_PWR_ACTIVE);
    delay_ms(50);
    acc_write(ACC_REG_RANGE, ACC_RANGE_6G);
    acc_write(ACC_REG_CONF, ACC_CONF_800HZ);

    /* 陀螺仪 */
    gy_write(GYRO_REG_LPM1, GYRO_LPM1_NORMAL);
    delay_ms(30);
    gy_write(GYRO_REG_RANGE, GYRO_RANGE_2000);
    gy_write(GYRO_REG_BANDWIDTH, GYRO_BW_116HZ);

    /* 重置状态 */
    cal_done = 0;
    cal_cnt = 0;
    sum_ax = 0;
    sum_gx = sum_gy = sum_gz = 0;
    first_sample = 0;
    angle_roll = angle_pitch = angle_yaw = 0;
    bmi088.Roll = bmi088.Pitch = bmi088.Yaw = 0;
    Gyro_Z_Measure = 0;
    Accel_Forward = 0;
}

/* ====================== 每10ms调用 ====================== */
void AHRS_Geteuler(void)
{
    uint8_t raw[6];

    /* 读加速度计 (G) */
    acc_read(ACC_REG_DATA, raw, 6);
    float ax = (float)get_i16(raw, 0) * ACC_SCALE_G;

    /* 读陀螺仪 (deg/s) */
    gy_read(GYRO_REG_DATA, raw, 6);
    float gx = (float)get_i16(raw, 0) * GYRO_SCALE_DPS;
    float gy = (float)get_i16(raw, 2) * GYRO_SCALE_DPS;
    float gz = (float)get_i16(raw, 4) * GYRO_SCALE_DPS;

    /* 低通滤波 */
    if (!first_sample) {
        flt_ax = ax;
        flt_gx = gx; flt_gy = gy; flt_gz = gz;
        first_sample = 1;
    } else {
        flt_ax = lpf(flt_ax, ax, LPF_ALPHA);
        flt_gx = lpf(flt_gx, gx, LPF_ALPHA);
        flt_gy = lpf(flt_gy, gy, LPF_ALPHA);
        flt_gz = lpf(flt_gz, gz, LPF_ALPHA);
    }
    Gyro_Z_Raw = flt_gz;

    /* 校准阶段: 采集零偏 (上电后保持静止) */
    if (!cal_done) {
        sum_ax += flt_ax;
        sum_gx += flt_gx;
        sum_gy += flt_gy;
        sum_gz += flt_gz;
        Accel_Forward = 0.0f;
        if (++cal_cnt >= CAL_SAMPLES) {
            float inv = 1.0f / (float)CAL_SAMPLES;
            bias_ax = sum_ax * inv;
            bias_gx = sum_gx * inv;
            bias_gy = sum_gy * inv;
            bias_gz = sum_gz * inv;
            angle_roll  = 0.0f;
            angle_pitch = 0.0f;
            angle_yaw   = 0.0f;
            cal_done = 1;
        }
        return;
    }

    Accel_Forward = -(flt_ax - bias_ax) * 9.81f;

    /* 去零偏 */
    float dgx = flt_gx - bias_gx;
    float dgy = flt_gy - bias_gy;
    float dgz = flt_gz - bias_gz;

    /* 静止零漂死区 */
    if (fabs(dgx) < GYRO_DEADZONE) dgx = 0.0f;
    if (fabs(dgy) < GYRO_DEADZONE) dgy = 0.0f;
    if (fabs(dgz) < GYRO_DEADZONE) dgz = 0.0f;

    /* 全部纯陀螺仪积分 */
    angle_roll  += dgx * DT;
    angle_pitch += dgy * DT;
    angle_yaw   += dgz * DT;

    /* 输出 */
    bmi088.Roll  = angle_roll;
    bmi088.Pitch = angle_pitch;
    bmi088.Yaw   = angle_yaw;
    Gyro_Z_Measure = dgz * 0.0174532925f;
}
