/*
 * bmi088.h - BMI088 IMU驱动 + Mahony AHRS姿态解算
 * 替代 mpu6050.h，接口兼容
 *
 * SysConfig 配置:
 *   1. SPI外设命名 "BMI088" → SPI0, Controller, Motorola 4-wire, 8-bit,
 *      MSB first, CPOL=Low, CPHA=First Edge (Mode 0), Bit Rate=8MHz
 *      Pin: SCK=B18, PICO=B17, POCI=B19
 *      Chip Select: 随便选 CS0/CS1 凑数(不调用), DMA/Interrupt 全关
 *   2. GPIO Output "BMI088_ACC" → PA23, 初始 High
 *   3. GPIO Output "BMI088_GY"  → PA02, 初始 High
 */

#ifndef BMI088_H
#define BMI088_H

#include "ti_msp_dl_config.h"
#include <stdint.h>

/* 欧拉角结构体 (兼容原 mpu6050 命名) */
typedef struct {
    float Roll;   /* 横滚角, 度 */
    float Pitch;  /* 俯仰角, 度 */
    float Yaw;    /* 偏航角, 度 (连续累积, 不限于±180) */
} BMI088_DEF;

extern BMI088_DEF bmi088;     
extern float Gyro_Z_Measure;   /* Z轴角速度 rad/s */
extern float Gyro_Z_Raw;       /* Z轴滤波后原始角速度 deg/s (校准前) */
extern float Accel_Forward;    /* 前向加速度 m/s² (X负轴朝车头, 加速为正) */

void bmi088_init(void);        
void AHRS_Geteuler(void);      /*  每10ms调用一次 */

#endif
