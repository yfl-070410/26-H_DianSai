#ifndef __VOAF_H
#define __VOAF_H

#include <stdint.h>
#include <stdarg.h>

/* JustFloat格式发送浮点数据 */
/* num: 浮点数个数, 后面跟num个float参数 */
void vofa_printf(int num, ...);

#endif 
