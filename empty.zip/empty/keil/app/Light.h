#ifndef LIGHT_H
#define LIGHT_H

#include "ti_msp_dl_config.h"

void Light_open();

void Light_close();

#endif