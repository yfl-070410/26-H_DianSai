#ifndef COMMON_HAND_H
#define COMMON_HAND_H

#include "ti_msp_dl_config.h"
#include "line_sensor.h"
#include "motor.h"
#include "PID.h"
#include "See_uart.h"
#include "BSP_uart.h"
#include "music.h"
#include "oled.h"
#include "vofa+.h"
#include <string.h>
#include <math.h>
#include "xunji_task.h"
#include <stdio.h>
#include <stdarg.h>
#include <stdbool.h>
#include "WuXian.h"
#include "Light.h"
#include "Delay.h"
#include "key.h"
#include "Liangan.h"
#include "bmi088.h"

#endif