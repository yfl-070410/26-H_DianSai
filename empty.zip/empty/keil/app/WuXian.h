#ifndef WUXIAN_H
#define WUXIAN_H

#include "ti_msp_dl_config.h"
#include <stdint.h>

/* NRF24L01 引脚定义 (CE/IRQ 来自 SysConfig WuXian 组, CSN 用户指定 PB25) */
#define NRF24L01_CE_PORT        GPIOA
#define NRF24L01_CE_PIN         DL_GPIO_PIN_28
#define NRF24L01_CSN_PORT       GPIOB
#define NRF24L01_CSN_PIN        DL_GPIO_PIN_25

/* NRF24L01 SPI 命令 */
#define NRF_READ_REG    0x00
#define NRF_WRITE_REG   0x20
#define NRF_RD_RX_PLOAD 0x61
#define NRF_WR_TX_PLOAD 0xA0
#define NRF_FLUSH_TX    0xE1
#define NRF_FLUSH_RX    0xE2
#define NRF_NOP         0xFF

/* NRF24L01 寄存器地址 */
#define NRF_REG_CONFIG      0x00
#define NRF_REG_EN_AA       0x01
#define NRF_REG_EN_RXADDR   0x02
#define NRF_REG_SETUP_AW    0x03
#define NRF_REG_SETUP_RETR  0x04
#define NRF_REG_RF_CH       0x05
#define NRF_REG_RF_SETUP    0x06
#define NRF_REG_STATUS      0x07
#define NRF_REG_OBSERVE_TX  0x08
#define NRF_REG_RX_ADDR_P0  0x0A
#define NRF_REG_TX_ADDR     0x10
#define NRF_REG_RX_PW_P0    0x11
#define NRF_REG_FIFO_STATUS 0x17

/* STATUS 寄存器位 */
#define NRF_FLAG_RX_DR      0x40
#define NRF_FLAG_TX_DS      0x20
#define NRF_FLAG_MAX_RT     0x10

/* 返回值 */
#define NRF_OK              0
#define NRF_ERR_MAX_RT      1
#define NRF_ERR_TIMEOUT     2
#define NRF_NO_DATA         3

/* 数据宽度 */
#define NRF24L01_PLOAD_WIDTH    32

void NRF24L01_Init(void);
void NRF24L01_TX_Mode(void);
void NRF24L01_RX_Mode(void);
uint8_t NRF24L01_Check(void);
uint8_t NRF24L01_SendData(uint8_t *buf);
uint8_t NRF24L01_ReceiveData(uint8_t *buf);

#endif
