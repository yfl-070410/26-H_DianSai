#include "Common_hand.h"


static const uint8_t voaf_tail[4] = {0x00, 0x00, 0x80, 0x7F};


void vofa_printf(int num, ...)
{
    va_list args;
    uint8_t buf[4];
    float val;
    int i, j;

    va_start(args, num);

    for (i = 0; i < num; i++)
    {
        val = (float)va_arg(args, double);
        memcpy(buf, &val, 4);
        for (j = 0; j < 4; j++)
        {
            while (DL_UART_Main_isBusy(vofa_uart_INST))
                ;
            DL_UART_Main_transmitData(vofa_uart_INST, buf[j]);
        }
    }


    for (j = 0; j < 4; j++)
    {
        while (DL_UART_Main_isBusy(vofa_uart_INST))
            ;
        DL_UART_Main_transmitData(vofa_uart_INST, voaf_tail[j]);
    }

    va_end(args);
}
