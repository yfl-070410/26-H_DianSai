#include "Common_hand.h"

/* 5字节地址 + 通道40 (2440MHz) */
static const uint8_t NRF24L01_ADDR[5] = {0x34, 0x43, 0x10, 0x10, 0x01};
#define NRF24L01_CH     40

/* ==================== SPI 底层 (共用 SPI0) ==================== */

static void nrf_csn_lo(void) { DL_GPIO_clearPins(NRF24L01_CSN_PORT, NRF24L01_CSN_PIN); }
static void nrf_csn_hi(void) { DL_GPIO_setPins(NRF24L01_CSN_PORT, NRF24L01_CSN_PIN); }
static void nrf_ce_lo(void)  { DL_GPIO_clearPins(NRF24L01_CE_PORT, NRF24L01_CE_PIN); }
static void nrf_ce_hi(void)  { DL_GPIO_setPins(NRF24L01_CE_PORT, NRF24L01_CE_PIN); }

static void nrf_flush_rx_fifo(void)
{
    while (!DL_SPI_isRXFIFOEmpty(BMI088_INST))
        (void)DL_SPI_receiveData8(BMI088_INST);
}

static uint8_t nrf_spi_xfer(uint8_t d)
{
    DL_SPI_transmitDataBlocking8(BMI088_INST, d);
    return DL_SPI_receiveDataBlocking8(BMI088_INST);
}

static uint8_t nrf_write_reg(uint8_t reg, uint8_t val)
{
    uint8_t status;
    nrf_flush_rx_fifo();
    nrf_csn_lo();
    status = nrf_spi_xfer(NRF_WRITE_REG | reg);
    nrf_spi_xfer(val);
    nrf_csn_hi();
    return status;
}

static uint8_t nrf_read_reg(uint8_t reg)
{
    uint8_t val;
    nrf_flush_rx_fifo();
    nrf_csn_lo();
    nrf_spi_xfer(NRF_READ_REG | reg);
    val = nrf_spi_xfer(0xFF);
    nrf_csn_hi();
    return val;
}

static void nrf_write_buf(uint8_t reg, const uint8_t *buf, uint8_t len)
{
    nrf_flush_rx_fifo();
    nrf_csn_lo();
    nrf_spi_xfer(NRF_WRITE_REG | reg);
    for (uint8_t i = 0; i < len; i++)
        nrf_spi_xfer(buf[i]);
    nrf_csn_hi();
}

static void nrf_read_buf(uint8_t reg, uint8_t *buf, uint8_t len)
{
    nrf_flush_rx_fifo();
    nrf_csn_lo();
    nrf_spi_xfer(NRF_READ_REG | reg);
    for (uint8_t i = 0; i < len; i++)
        buf[i] = nrf_spi_xfer(0xFF);
    nrf_csn_hi();
}

static void nrf_cmd(uint8_t cmd)
{
    nrf_flush_rx_fifo();
    nrf_csn_lo();
    nrf_spi_xfer(cmd);
    nrf_csn_hi();
}

/* ==================== NRF24L01 接口 ==================== */

uint8_t NRF24L01_Check(void)
{
    uint8_t buf[5];
    uint8_t test[5] = {0xA5, 0xA5, 0xA5, 0xA5, 0xA5};

    nrf_write_buf(NRF_REG_TX_ADDR, test, 5);
    nrf_read_buf(NRF_REG_TX_ADDR, buf, 5);

    for (uint8_t i = 0; i < 5; i++) {
        if (buf[i] != 0xA5)
            return 1;
    }
    return 0;
}

void NRF24L01_Init(void)
{
    /* IRQ(PA31) 被SysConfig配成了推挽输出并拉高, 会和NRF模块自己的IRQ输出脚打架,
       导致SPI读写异常/检测失败, 这里改回输入 */
    DL_GPIO_disableOutput(WuXian_IRQ_PORT, WuXian_IRQ_PIN);
    DL_GPIO_initDigitalInput(WuXian_IRQ_IOMUX);

    /* 8MHz在杜邦线上对NRF24L01不稳, 降到4MHz (32M / (2*(3+1))) */
    DL_SPI_disable(BMI088_INST);
    DL_SPI_setBitRateSerialClockDivider(BMI088_INST, 3);
    DL_SPI_enable(BMI088_INST);

    /* CSN 引脚初始化为高电平(未选中) */
    DL_GPIO_initDigitalOutput(IOMUX_PINCM56);
    DL_GPIO_setPins(NRF24L01_CSN_PORT, NRF24L01_CSN_PIN);
    DL_GPIO_enableOutput(NRF24L01_CSN_PORT, NRF24L01_CSN_PIN);

    nrf_ce_lo();
    nrf_csn_hi();
    Delay_ms(5);

    nrf_write_reg(NRF_REG_CONFIG, 0x0E);
    nrf_write_reg(NRF_REG_EN_AA, 0x01);
    nrf_write_reg(NRF_REG_EN_RXADDR, 0x01);
    nrf_write_reg(NRF_REG_SETUP_AW, 0x03);
    nrf_write_reg(NRF_REG_SETUP_RETR, 0x1A);
    nrf_write_reg(NRF_REG_RF_CH, NRF24L01_CH);
    nrf_write_reg(NRF_REG_RF_SETUP, 0x0F);
    nrf_write_buf(NRF_REG_TX_ADDR, NRF24L01_ADDR, 5);
    nrf_write_buf(NRF_REG_RX_ADDR_P0, NRF24L01_ADDR, 5);
    nrf_write_reg(NRF_REG_RX_PW_P0, NRF24L01_PLOAD_WIDTH);

    nrf_cmd(NRF_FLUSH_TX);
    nrf_cmd(NRF_FLUSH_RX);
    nrf_write_reg(NRF_REG_STATUS, 0x70);
}

void NRF24L01_TX_Mode(void)
{
    nrf_ce_lo();
    nrf_write_buf(NRF_REG_TX_ADDR, NRF24L01_ADDR, 5);
    nrf_write_buf(NRF_REG_RX_ADDR_P0, NRF24L01_ADDR, 5);
    nrf_write_reg(NRF_REG_CONFIG, 0x0E);
    nrf_ce_hi();
    delay_cycles(320);
}

void NRF24L01_RX_Mode(void)
{
    nrf_ce_lo();
    nrf_write_buf(NRF_REG_RX_ADDR_P0, NRF24L01_ADDR, 5);
    nrf_write_reg(NRF_REG_RX_PW_P0, NRF24L01_PLOAD_WIDTH);
    nrf_write_reg(NRF_REG_CONFIG, 0x0F);
    nrf_ce_hi();
    delay_cycles(320);
}

uint8_t NRF24L01_SendData(uint8_t *buf)
{
    uint8_t status;
    uint32_t timeout = 0;

    nrf_ce_lo();
    nrf_cmd(NRF_FLUSH_TX);

    nrf_flush_rx_fifo();
    nrf_csn_lo();
    nrf_spi_xfer(NRF_WR_TX_PLOAD);
    for (uint8_t i = 0; i < NRF24L01_PLOAD_WIDTH; i++)
        nrf_spi_xfer(buf[i]);
    nrf_csn_hi();

    nrf_ce_hi();

    while (1) {
        status = nrf_read_reg(NRF_REG_STATUS);
        if (status & NRF_FLAG_TX_DS) {
            nrf_write_reg(NRF_REG_STATUS, NRF_FLAG_TX_DS);
            return NRF_OK;
        }
        if (status & NRF_FLAG_MAX_RT) {
            nrf_write_reg(NRF_REG_STATUS, NRF_FLAG_MAX_RT);
            nrf_cmd(NRF_FLUSH_TX);
            return NRF_ERR_MAX_RT;
        }
        if (++timeout > 50000)
            return NRF_ERR_TIMEOUT;
    }
}

uint8_t NRF24L01_ReceiveData(uint8_t *buf)
{
    uint8_t status = nrf_read_reg(NRF_REG_STATUS);

    if (status & NRF_FLAG_RX_DR) {
        nrf_flush_rx_fifo();
        nrf_csn_lo();
        nrf_spi_xfer(NRF_RD_RX_PLOAD);
        for (uint8_t i = 0; i < NRF24L01_PLOAD_WIDTH; i++)
            buf[i] = nrf_spi_xfer(0xFF);
        nrf_csn_hi();

        nrf_write_reg(NRF_REG_STATUS, NRF_FLAG_RX_DR);
        nrf_cmd(NRF_FLUSH_RX);
        return NRF_OK;
    }
    return NRF_NO_DATA;
}


