#ifndef OLED_H
#define OLED_H

#include "ti_msp_dl_config.h"
#include <stdint.h>

/* SSD1306 I2C 7-bit address, change to 0x3D if your module uses that */
#define OLED_ADDR   0x3C


#define OLED_W      128
#define OLED_Hi      64
#define OLED_PAGES  8

/*  x: pixel column  0-127  (each char occupies 6 pixels)
 *  y: page row      0-7    (each page is 8 pixels tall)
 *
 *  Usage:
 *      OLED_Init(I2C0);
 *      OLED_Clear();
 *      OLED_ShowString(0, 0, "Hello!");
 *      OLED_Printf(0, 1, "val=%d", 42);
 */

void OLED_Init(I2C_Regs *i2c);
void OLED_Clear(void);
void OLED_ShowChar(uint8_t x, uint8_t y, char ch);
void OLED_ShowString(uint8_t x, uint8_t y, const char *str);
void OLED_ShowNum(uint8_t x, uint8_t y, int32_t num);
void OLED_ShowFloat(uint8_t x, uint8_t y, float val, uint8_t dec);
void OLED_Printf(uint8_t x, uint8_t y, const char *fmt, ...);

#endif
