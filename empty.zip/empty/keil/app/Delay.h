#ifndef DELAY_H
#define DELAY_H

#include "ti_msp_dl_config.h"

void Delay_ms(uint16_t ms);

void Delay_s(uint16_t s);

#endif