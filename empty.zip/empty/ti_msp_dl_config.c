/*
 * Copyright (c) 2023, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ============ ti_msp_dl_config.c =============
 *  Configured MSPM0 DriverLib module definitions
 *
 *  DO NOT EDIT - This file is generated for the MSPM0G350X
 *  by the SysConfig tool.
 */

#include "ti_msp_dl_config.h"

DL_TimerA_backupConfig gPWMaBackup;
DL_TimerG_backupConfig gDuojiBackup;
DL_TimerA_backupConfig gYuntai_taskBackup;
DL_UART_Main_backupConfig gLianganBackup;
DL_SPI_backupConfig gBMI088Backup;

/*
 *  ======== SYSCFG_DL_init ========
 *  Perform any initialization needed before using any board APIs
 */
SYSCONFIG_WEAK void SYSCFG_DL_init(void)
{
    SYSCFG_DL_initPower();
    SYSCFG_DL_GPIO_init();
    /* Module-Specific Initializations*/
    SYSCFG_DL_SYSCTL_init();
    SYSCFG_DL_PWMa_init();
    SYSCFG_DL_Duoji_init();
    SYSCFG_DL_Xunji_task_init();
    SYSCFG_DL_Yuntai_task_init();
    SYSCFG_DL_OLED_init();
    SYSCFG_DL_vofa_uart_init();
    SYSCFG_DL_see_uart_init();
    SYSCFG_DL_Liangan_init();
    SYSCFG_DL_BMI088_init();
    SYSCFG_DL_DMA_init();
    /* Ensure backup structures have no valid state */
	gPWMaBackup.backupRdy 	= false;
	gDuojiBackup.backupRdy 	= false;
	gYuntai_taskBackup.backupRdy 	= false;
	gLianganBackup.backupRdy 	= false;
	gBMI088Backup.backupRdy 	= false;

}
/*
 * User should take care to save and restore register configuration in application.
 * See Retention Configuration section for more details.
 */
SYSCONFIG_WEAK bool SYSCFG_DL_saveConfiguration(void)
{
    bool retStatus = true;

	retStatus &= DL_TimerA_saveConfiguration(PWMa_INST, &gPWMaBackup);
	retStatus &= DL_TimerG_saveConfiguration(Duoji_INST, &gDuojiBackup);
	retStatus &= DL_TimerA_saveConfiguration(Yuntai_task_INST, &gYuntai_taskBackup);
	retStatus &= DL_UART_Main_saveConfiguration(Liangan_INST, &gLianganBackup);
	retStatus &= DL_SPI_saveConfiguration(BMI088_INST, &gBMI088Backup);

    return retStatus;
}


SYSCONFIG_WEAK bool SYSCFG_DL_restoreConfiguration(void)
{
    bool retStatus = true;

	retStatus &= DL_TimerA_restoreConfiguration(PWMa_INST, &gPWMaBackup, false);
	retStatus &= DL_TimerG_restoreConfiguration(Duoji_INST, &gDuojiBackup, false);
	retStatus &= DL_TimerA_restoreConfiguration(Yuntai_task_INST, &gYuntai_taskBackup, false);
	retStatus &= DL_UART_Main_restoreConfiguration(Liangan_INST, &gLianganBackup);
	retStatus &= DL_SPI_restoreConfiguration(BMI088_INST, &gBMI088Backup);

    return retStatus;
}

SYSCONFIG_WEAK void SYSCFG_DL_initPower(void)
{
    DL_GPIO_reset(GPIOA);
    DL_GPIO_reset(GPIOB);
    DL_TimerA_reset(PWMa_INST);
    DL_TimerG_reset(Duoji_INST);
    DL_TimerG_reset(Xunji_task_INST);
    DL_TimerA_reset(Yuntai_task_INST);
    DL_I2C_reset(OLED_INST);
    DL_UART_Main_reset(vofa_uart_INST);
    DL_UART_Main_reset(see_uart_INST);
    DL_UART_Main_reset(Liangan_INST);
    DL_SPI_reset(BMI088_INST);


    DL_GPIO_enablePower(GPIOA);
    DL_GPIO_enablePower(GPIOB);
    DL_TimerA_enablePower(PWMa_INST);
    DL_TimerG_enablePower(Duoji_INST);
    DL_TimerG_enablePower(Xunji_task_INST);
    DL_TimerA_enablePower(Yuntai_task_INST);
    DL_I2C_enablePower(OLED_INST);
    DL_UART_Main_enablePower(vofa_uart_INST);
    DL_UART_Main_enablePower(see_uart_INST);
    DL_UART_Main_enablePower(Liangan_INST);
    DL_SPI_enablePower(BMI088_INST);

    delay_cycles(POWER_STARTUP_DELAY);
}

SYSCONFIG_WEAK void SYSCFG_DL_GPIO_init(void)
{

    DL_GPIO_initPeripheralOutputFunction(GPIO_PWMa_C0_IOMUX,GPIO_PWMa_C0_IOMUX_FUNC);
    DL_GPIO_enableOutput(GPIO_PWMa_C0_PORT, GPIO_PWMa_C0_PIN);
    DL_GPIO_initPeripheralOutputFunction(GPIO_PWMa_C1_IOMUX,GPIO_PWMa_C1_IOMUX_FUNC);
    DL_GPIO_enableOutput(GPIO_PWMa_C1_PORT, GPIO_PWMa_C1_PIN);
    DL_GPIO_initPeripheralOutputFunction(GPIO_Duoji_C0_IOMUX,GPIO_Duoji_C0_IOMUX_FUNC);
    DL_GPIO_enableOutput(GPIO_Duoji_C0_PORT, GPIO_Duoji_C0_PIN);
    DL_GPIO_initPeripheralOutputFunction(GPIO_Duoji_C1_IOMUX,GPIO_Duoji_C1_IOMUX_FUNC);
    DL_GPIO_enableOutput(GPIO_Duoji_C1_PORT, GPIO_Duoji_C1_PIN);

    
	DL_GPIO_initPeripheralInputFunction(
		 GPIO_OLED_IOMUX_SDA, GPIO_OLED_IOMUX_SDA_FUNC);
	DL_GPIO_initPeripheralInputFunction(
		 GPIO_OLED_IOMUX_SCL, GPIO_OLED_IOMUX_SCL_FUNC);
    DL_GPIO_enableHiZ(GPIO_OLED_IOMUX_SDA);
    DL_GPIO_enableHiZ(GPIO_OLED_IOMUX_SCL);

    DL_GPIO_initPeripheralOutputFunction(
        GPIO_vofa_uart_IOMUX_TX, GPIO_vofa_uart_IOMUX_TX_FUNC);
    DL_GPIO_initPeripheralInputFunction(
        GPIO_vofa_uart_IOMUX_RX, GPIO_vofa_uart_IOMUX_RX_FUNC);
    DL_GPIO_initPeripheralOutputFunction(
        GPIO_see_uart_IOMUX_TX, GPIO_see_uart_IOMUX_TX_FUNC);
    DL_GPIO_initPeripheralInputFunction(
        GPIO_see_uart_IOMUX_RX, GPIO_see_uart_IOMUX_RX_FUNC);
    DL_GPIO_initPeripheralOutputFunction(
        GPIO_Liangan_IOMUX_TX, GPIO_Liangan_IOMUX_TX_FUNC);
    DL_GPIO_initPeripheralInputFunction(
        GPIO_Liangan_IOMUX_RX, GPIO_Liangan_IOMUX_RX_FUNC);

    DL_GPIO_initPeripheralOutputFunction(
        GPIO_BMI088_IOMUX_SCLK, GPIO_BMI088_IOMUX_SCLK_FUNC);
    DL_GPIO_initPeripheralOutputFunction(
        GPIO_BMI088_IOMUX_PICO, GPIO_BMI088_IOMUX_PICO_FUNC);
    DL_GPIO_initPeripheralInputFunction(
        GPIO_BMI088_IOMUX_POCI, GPIO_BMI088_IOMUX_POCI_FUNC);
    DL_GPIO_initPeripheralOutputFunction(
        GPIO_BMI088_IOMUX_CS0, GPIO_BMI088_IOMUX_CS0_FUNC);

    DL_GPIO_initDigitalOutput(tb66_stay_tb66_stay_pin_IOMUX);

    DL_GPIO_initDigitalOutput(Music_music_IOMUX);

    DL_GPIO_initDigitalOutput(DianCiTie_diancitie_IOMUX);

    DL_GPIO_initDigitalOutput(LED_led_IOMUX);

    DL_GPIO_initDigitalInputFeatures(Motor_Ender_Motor_RIGHT_A_IOMUX,
		 DL_GPIO_INVERSION_DISABLE, DL_GPIO_RESISTOR_PULL_UP,
		 DL_GPIO_HYSTERESIS_DISABLE, DL_GPIO_WAKEUP_DISABLE);

    DL_GPIO_initDigitalInputFeatures(Motor_Ender_Motor_RIGHT_B_IOMUX,
		 DL_GPIO_INVERSION_DISABLE, DL_GPIO_RESISTOR_PULL_UP,
		 DL_GPIO_HYSTERESIS_DISABLE, DL_GPIO_WAKEUP_DISABLE);

    DL_GPIO_initDigitalInputFeatures(Motor_Ender_Motor_LEFT_A_IOMUX,
		 DL_GPIO_INVERSION_DISABLE, DL_GPIO_RESISTOR_PULL_UP,
		 DL_GPIO_HYSTERESIS_DISABLE, DL_GPIO_WAKEUP_DISABLE);

    DL_GPIO_initDigitalInputFeatures(Motor_Ender_Motor_LEFT_B_IOMUX,
		 DL_GPIO_INVERSION_DISABLE, DL_GPIO_RESISTOR_PULL_UP,
		 DL_GPIO_HYSTERESIS_DISABLE, DL_GPIO_WAKEUP_DISABLE);

    DL_GPIO_initDigitalOutput(Motor_Pin_RIGHT_Pin1_IOMUX);

    DL_GPIO_initDigitalOutput(Motor_Pin_RIGHT_Pin2_IOMUX);

    DL_GPIO_initDigitalOutput(Motor_Pin_LEFT_Pin2_IOMUX);

    DL_GPIO_initDigitalOutput(Motor_Pin_LEFT_Pin1_IOMUX);

    DL_GPIO_initDigitalInputFeatures(Key_Start_Key_IOMUX,
		 DL_GPIO_INVERSION_DISABLE, DL_GPIO_RESISTOR_PULL_UP,
		 DL_GPIO_HYSTERESIS_DISABLE, DL_GPIO_WAKEUP_DISABLE);

    DL_GPIO_initDigitalInputFeatures(Key_Mode_Change_key_IOMUX,
		 DL_GPIO_INVERSION_DISABLE, DL_GPIO_RESISTOR_PULL_UP,
		 DL_GPIO_HYSTERESIS_DISABLE, DL_GPIO_WAKEUP_DISABLE);

    DL_GPIO_initDigitalInput(line_sensor_PIN_0_IOMUX);

    DL_GPIO_initDigitalInput(line_sensor_PIN_1_IOMUX);

    DL_GPIO_initDigitalInput(line_sensor_PIN_2_IOMUX);

    DL_GPIO_initDigitalInput(line_sensor_PIN_3_IOMUX);

    DL_GPIO_initDigitalInput(line_sensor_PIN_4_IOMUX);

    DL_GPIO_initDigitalInput(line_sensor_PIN_5_IOMUX);

    DL_GPIO_initDigitalInput(line_sensor_PIN_6_IOMUX);

    DL_GPIO_initDigitalInput(line_sensor_PIN_7_IOMUX);

    DL_GPIO_initDigitalOutput(BMI088_pin_BMI088_ACC_IOMUX);

    DL_GPIO_initDigitalOutput(BMI088_pin_BMI088_GY_IOMUX);

    DL_GPIO_initDigitalOutput(WuXian_CE_IOMUX);

    DL_GPIO_initDigitalInputFeatures(WuXian_IRQ_IOMUX,
		 DL_GPIO_INVERSION_DISABLE, DL_GPIO_RESISTOR_PULL_UP,
		 DL_GPIO_HYSTERESIS_DISABLE, DL_GPIO_WAKEUP_DISABLE);

    DL_GPIO_initDigitalOutput(WuXian_WuXian_Cs_IOMUX);

    DL_GPIO_clearPins(GPIOA, Music_music_PIN);
    DL_GPIO_setPins(GPIOA, BMI088_pin_BMI088_ACC_PIN |
		WuXian_CE_PIN);
    DL_GPIO_enableOutput(GPIOA, Music_music_PIN |
		BMI088_pin_BMI088_ACC_PIN |
		WuXian_CE_PIN);
    DL_GPIO_setUpperPinsPolarity(GPIOA, DL_GPIO_PIN_16_EDGE_FALL |
		DL_GPIO_PIN_30_EDGE_FALL |
		DL_GPIO_PIN_31_EDGE_FALL);
    DL_GPIO_clearInterruptStatus(GPIOA, Key_Start_Key_PIN |
		Key_Mode_Change_key_PIN |
		WuXian_IRQ_PIN);
    DL_GPIO_enableInterrupt(GPIOA, Key_Start_Key_PIN |
		Key_Mode_Change_key_PIN |
		WuXian_IRQ_PIN);
    DL_GPIO_clearPins(GPIOB, tb66_stay_tb66_stay_pin_PIN |
		DianCiTie_diancitie_PIN |
		LED_led_PIN |
		Motor_Pin_RIGHT_Pin1_PIN |
		Motor_Pin_RIGHT_Pin2_PIN |
		Motor_Pin_LEFT_Pin2_PIN |
		Motor_Pin_LEFT_Pin1_PIN |
		WuXian_WuXian_Cs_PIN);
    DL_GPIO_setPins(GPIOB, BMI088_pin_BMI088_GY_PIN);
    DL_GPIO_enableOutput(GPIOB, tb66_stay_tb66_stay_pin_PIN |
		DianCiTie_diancitie_PIN |
		LED_led_PIN |
		Motor_Pin_RIGHT_Pin1_PIN |
		Motor_Pin_RIGHT_Pin2_PIN |
		Motor_Pin_LEFT_Pin2_PIN |
		Motor_Pin_LEFT_Pin1_PIN |
		BMI088_pin_BMI088_GY_PIN |
		WuXian_WuXian_Cs_PIN);
    DL_GPIO_setUpperPinsPolarity(GPIOB, DL_GPIO_PIN_22_EDGE_RISE |
		DL_GPIO_PIN_20_EDGE_RISE);
    DL_GPIO_clearInterruptStatus(GPIOB, Motor_Ender_Motor_RIGHT_A_PIN |
		Motor_Ender_Motor_LEFT_A_PIN);
    DL_GPIO_enableInterrupt(GPIOB, Motor_Ender_Motor_RIGHT_A_PIN |
		Motor_Ender_Motor_LEFT_A_PIN);

}


SYSCONFIG_WEAK void SYSCFG_DL_SYSCTL_init(void)
{

	//Low Power Mode is configured to be SLEEP0
    DL_SYSCTL_setBORThreshold(DL_SYSCTL_BOR_THRESHOLD_LEVEL_0);

    DL_SYSCTL_setSYSOSCFreq(DL_SYSCTL_SYSOSC_FREQ_BASE);
    /* Set default configuration */
    DL_SYSCTL_disableHFXT();
    DL_SYSCTL_disableSYSPLL();
    DL_SYSCTL_setULPCLKDivider(DL_SYSCTL_ULPCLK_DIV_1);
    DL_SYSCTL_setMCLKDivider(DL_SYSCTL_MCLK_DIVIDER_DISABLE);

}


/*
 * Timer clock configuration to be sourced by  / 1 (32000000 Hz)
 * timerClkFreq = (timerClkSrc / (timerClkDivRatio * (timerClkPrescale + 1)))
 *   32000000 Hz = 32000000 Hz / (1 * (0 + 1))
 */
static const DL_TimerA_ClockConfig gPWMaClockConfig = {
    .clockSel = DL_TIMER_CLOCK_BUSCLK,
    .divideRatio = DL_TIMER_CLOCK_DIVIDE_1,
    .prescale = 0U
};

static const DL_TimerA_PWMConfig gPWMaConfig = {
    .pwmMode = DL_TIMER_PWM_MODE_EDGE_ALIGN_UP,
    .period = 1600,
    .isTimerWithFourCC = false,
    .startTimer = DL_TIMER_STOP,
};

SYSCONFIG_WEAK void SYSCFG_DL_PWMa_init(void) {

    DL_TimerA_setClockConfig(
        PWMa_INST, (DL_TimerA_ClockConfig *) &gPWMaClockConfig);

    DL_TimerA_initPWMMode(
        PWMa_INST, (DL_TimerA_PWMConfig *) &gPWMaConfig);

    DL_TimerA_setCaptureCompareOutCtl(PWMa_INST, DL_TIMER_CC_OCTL_INIT_VAL_LOW,
		DL_TIMER_CC_OCTL_INV_OUT_DISABLED, DL_TIMER_CC_OCTL_SRC_FUNCVAL,
		DL_TIMERA_CAPTURE_COMPARE_0_INDEX);

    DL_TimerA_setCaptCompUpdateMethod(PWMa_INST, DL_TIMER_CC_UPDATE_METHOD_IMMEDIATE, DL_TIMERA_CAPTURE_COMPARE_0_INDEX);
    DL_TimerA_setCaptureCompareValue(PWMa_INST, 0, DL_TIMER_CC_0_INDEX);

    DL_TimerA_setCaptureCompareOutCtl(PWMa_INST, DL_TIMER_CC_OCTL_INIT_VAL_LOW,
		DL_TIMER_CC_OCTL_INV_OUT_DISABLED, DL_TIMER_CC_OCTL_SRC_FUNCVAL,
		DL_TIMERA_CAPTURE_COMPARE_1_INDEX);

    DL_TimerA_setCaptCompUpdateMethod(PWMa_INST, DL_TIMER_CC_UPDATE_METHOD_IMMEDIATE, DL_TIMERA_CAPTURE_COMPARE_1_INDEX);
    DL_TimerA_setCaptureCompareValue(PWMa_INST, 0, DL_TIMER_CC_1_INDEX);

    DL_TimerA_enableClock(PWMa_INST);


    
    DL_TimerA_setCCPDirection(PWMa_INST , DL_TIMER_CC0_OUTPUT | DL_TIMER_CC1_OUTPUT );


}
/*
 * Timer clock configuration to be sourced by  / 1 (32000000 Hz)
 * timerClkFreq = (timerClkSrc / (timerClkDivRatio * (timerClkPrescale + 1)))
 *   32000000 Hz = 32000000 Hz / (1 * (0 + 1))
 */
static const DL_TimerG_ClockConfig gDuojiClockConfig = {
    .clockSel = DL_TIMER_CLOCK_BUSCLK,
    .divideRatio = DL_TIMER_CLOCK_DIVIDE_1,
    .prescale = 0U
};

static const DL_TimerG_PWMConfig gDuojiConfig = {
    .pwmMode = DL_TIMER_PWM_MODE_EDGE_ALIGN_UP,
    .period = 1600,
    .startTimer = DL_TIMER_STOP,
};

SYSCONFIG_WEAK void SYSCFG_DL_Duoji_init(void) {

    DL_TimerG_setClockConfig(
        Duoji_INST, (DL_TimerG_ClockConfig *) &gDuojiClockConfig);

    DL_TimerG_initPWMMode(
        Duoji_INST, (DL_TimerG_PWMConfig *) &gDuojiConfig);

    DL_TimerG_setCaptureCompareOutCtl(Duoji_INST, DL_TIMER_CC_OCTL_INIT_VAL_LOW,
		DL_TIMER_CC_OCTL_INV_OUT_DISABLED, DL_TIMER_CC_OCTL_SRC_FUNCVAL,
		DL_TIMERG_CAPTURE_COMPARE_0_INDEX);

    DL_TimerG_setCaptCompUpdateMethod(Duoji_INST, DL_TIMER_CC_UPDATE_METHOD_IMMEDIATE, DL_TIMERG_CAPTURE_COMPARE_0_INDEX);
    DL_TimerG_setCaptureCompareValue(Duoji_INST, 0, DL_TIMER_CC_0_INDEX);

    DL_TimerG_setCaptureCompareOutCtl(Duoji_INST, DL_TIMER_CC_OCTL_INIT_VAL_LOW,
		DL_TIMER_CC_OCTL_INV_OUT_DISABLED, DL_TIMER_CC_OCTL_SRC_FUNCVAL,
		DL_TIMERG_CAPTURE_COMPARE_1_INDEX);

    DL_TimerG_setCaptCompUpdateMethod(Duoji_INST, DL_TIMER_CC_UPDATE_METHOD_IMMEDIATE, DL_TIMERG_CAPTURE_COMPARE_1_INDEX);
    DL_TimerG_setCaptureCompareValue(Duoji_INST, 0, DL_TIMER_CC_1_INDEX);

    DL_TimerG_enableClock(Duoji_INST);


    
    DL_TimerG_setCCPDirection(Duoji_INST , DL_TIMER_CC0_OUTPUT | DL_TIMER_CC1_OUTPUT );


}



/*
 * Timer clock configuration to be sourced by BUSCLK /  (8000000 Hz)
 * timerClkFreq = (timerClkSrc / (timerClkDivRatio * (timerClkPrescale + 1)))
 *   2000000 Hz = 8000000 Hz / (4 * (3 + 1))
 */
static const DL_TimerG_ClockConfig gXunji_taskClockConfig = {
    .clockSel    = DL_TIMER_CLOCK_BUSCLK,
    .divideRatio = DL_TIMER_CLOCK_DIVIDE_4,
    .prescale    = 3U,
};

/*
 * Timer load value (where the counter starts from) is calculated as (timerPeriod * timerClockFreq) - 1
 * Xunji_task_INST_LOAD_VALUE = (10 ms * 2000000 Hz) - 1
 */
static const DL_TimerG_TimerConfig gXunji_taskTimerConfig = {
    .period     = Xunji_task_INST_LOAD_VALUE,
    .timerMode  = DL_TIMER_TIMER_MODE_PERIODIC,
    .startTimer = DL_TIMER_STOP,
};

SYSCONFIG_WEAK void SYSCFG_DL_Xunji_task_init(void) {

    DL_TimerG_setClockConfig(Xunji_task_INST,
        (DL_TimerG_ClockConfig *) &gXunji_taskClockConfig);

    DL_TimerG_initTimerMode(Xunji_task_INST,
        (DL_TimerG_TimerConfig *) &gXunji_taskTimerConfig);
    DL_TimerG_enableInterrupt(Xunji_task_INST , DL_TIMERG_INTERRUPT_ZERO_EVENT);
    DL_TimerG_enableClock(Xunji_task_INST);





}

/*
 * Timer clock configuration to be sourced by BUSCLK /  (8000000 Hz)
 * timerClkFreq = (timerClkSrc / (timerClkDivRatio * (timerClkPrescale + 1)))
 *   2000000 Hz = 8000000 Hz / (4 * (3 + 1))
 */
static const DL_TimerA_ClockConfig gYuntai_taskClockConfig = {
    .clockSel    = DL_TIMER_CLOCK_BUSCLK,
    .divideRatio = DL_TIMER_CLOCK_DIVIDE_4,
    .prescale    = 3U,
};

/*
 * Timer load value (where the counter starts from) is calculated as (timerPeriod * timerClockFreq) - 1
 * Yuntai_task_INST_LOAD_VALUE = (10 ms * 2000000 Hz) - 1
 */
static const DL_TimerA_TimerConfig gYuntai_taskTimerConfig = {
    .period     = Yuntai_task_INST_LOAD_VALUE,
    .timerMode  = DL_TIMER_TIMER_MODE_PERIODIC,
    .startTimer = DL_TIMER_STOP,
};

SYSCONFIG_WEAK void SYSCFG_DL_Yuntai_task_init(void) {

    DL_TimerA_setClockConfig(Yuntai_task_INST,
        (DL_TimerA_ClockConfig *) &gYuntai_taskClockConfig);

    DL_TimerA_initTimerMode(Yuntai_task_INST,
        (DL_TimerA_TimerConfig *) &gYuntai_taskTimerConfig);
    DL_TimerA_enableInterrupt(Yuntai_task_INST , DL_TIMERA_INTERRUPT_ZERO_EVENT);
    DL_TimerA_enableClock(Yuntai_task_INST);





}


static const DL_I2C_ClockConfig gOLEDClockConfig = {
    .clockSel = DL_I2C_CLOCK_BUSCLK,
    .divideRatio = DL_I2C_CLOCK_DIVIDE_1,
};

SYSCONFIG_WEAK void SYSCFG_DL_OLED_init(void) {

    DL_I2C_setClockConfig(OLED_INST,
        (DL_I2C_ClockConfig *) &gOLEDClockConfig);
    DL_I2C_setAnalogGlitchFilterPulseWidth(OLED_INST,
        DL_I2C_ANALOG_GLITCH_FILTER_WIDTH_50NS);
    DL_I2C_enableAnalogGlitchFilter(OLED_INST);

    /* Configure Controller Mode */
    DL_I2C_resetControllerTransfer(OLED_INST);
    /* Set frequency to 100000 Hz*/
    DL_I2C_setTimerPeriod(OLED_INST, 31);
    DL_I2C_setControllerTXFIFOThreshold(OLED_INST, DL_I2C_TX_FIFO_LEVEL_EMPTY);
    DL_I2C_setControllerRXFIFOThreshold(OLED_INST, DL_I2C_RX_FIFO_LEVEL_BYTES_1);
    DL_I2C_enableControllerClockStretching(OLED_INST);


    /* Enable module */
    DL_I2C_enableController(OLED_INST);


}


static const DL_UART_Main_ClockConfig gvofa_uartClockConfig = {
    .clockSel    = DL_UART_MAIN_CLOCK_BUSCLK,
    .divideRatio = DL_UART_MAIN_CLOCK_DIVIDE_RATIO_1
};

static const DL_UART_Main_Config gvofa_uartConfig = {
    .mode        = DL_UART_MAIN_MODE_NORMAL,
    .direction   = DL_UART_MAIN_DIRECTION_TX_RX,
    .flowControl = DL_UART_MAIN_FLOW_CONTROL_NONE,
    .parity      = DL_UART_MAIN_PARITY_NONE,
    .wordLength  = DL_UART_MAIN_WORD_LENGTH_8_BITS,
    .stopBits    = DL_UART_MAIN_STOP_BITS_ONE
};

SYSCONFIG_WEAK void SYSCFG_DL_vofa_uart_init(void)
{
    DL_UART_Main_setClockConfig(vofa_uart_INST, (DL_UART_Main_ClockConfig *) &gvofa_uartClockConfig);

    DL_UART_Main_init(vofa_uart_INST, (DL_UART_Main_Config *) &gvofa_uartConfig);
    /*
     * Configure baud rate by setting oversampling and baud rate divisors.
     *  Target baud rate: 115200
     *  Actual baud rate: 115211.52
     */
    DL_UART_Main_setOversampling(vofa_uart_INST, DL_UART_OVERSAMPLING_RATE_16X);
    DL_UART_Main_setBaudRateDivisor(vofa_uart_INST, vofa_uart_IBRD_32_MHZ_115200_BAUD, vofa_uart_FBRD_32_MHZ_115200_BAUD);



    DL_UART_Main_enable(vofa_uart_INST);
}

static const DL_UART_Main_ClockConfig gsee_uartClockConfig = {
    .clockSel    = DL_UART_MAIN_CLOCK_BUSCLK,
    .divideRatio = DL_UART_MAIN_CLOCK_DIVIDE_RATIO_1
};

static const DL_UART_Main_Config gsee_uartConfig = {
    .mode        = DL_UART_MAIN_MODE_NORMAL,
    .direction   = DL_UART_MAIN_DIRECTION_TX_RX,
    .flowControl = DL_UART_MAIN_FLOW_CONTROL_NONE,
    .parity      = DL_UART_MAIN_PARITY_NONE,
    .wordLength  = DL_UART_MAIN_WORD_LENGTH_8_BITS,
    .stopBits    = DL_UART_MAIN_STOP_BITS_ONE
};

SYSCONFIG_WEAK void SYSCFG_DL_see_uart_init(void)
{
    DL_UART_Main_setClockConfig(see_uart_INST, (DL_UART_Main_ClockConfig *) &gsee_uartClockConfig);

    DL_UART_Main_init(see_uart_INST, (DL_UART_Main_Config *) &gsee_uartConfig);
    /*
     * Configure baud rate by setting oversampling and baud rate divisors.
     *  Target baud rate: 115200
     *  Actual baud rate: 115211.52
     */
    DL_UART_Main_setOversampling(see_uart_INST, DL_UART_OVERSAMPLING_RATE_16X);
    DL_UART_Main_setBaudRateDivisor(see_uart_INST, see_uart_IBRD_32_MHZ_115200_BAUD, see_uart_FBRD_32_MHZ_115200_BAUD);


    /* Configure Interrupts */
    DL_UART_Main_enableInterrupt(see_uart_INST,
                                 DL_UART_MAIN_INTERRUPT_DMA_DONE_RX);

    /* Configure DMA Receive Event */
    DL_UART_Main_enableDMAReceiveEvent(see_uart_INST, DL_UART_DMA_INTERRUPT_RX);
    /* Configure FIFOs */
    DL_UART_Main_enableFIFOs(see_uart_INST);
    DL_UART_Main_setRXFIFOThreshold(see_uart_INST, DL_UART_RX_FIFO_LEVEL_1_2_FULL);
    DL_UART_Main_setTXFIFOThreshold(see_uart_INST, DL_UART_TX_FIFO_LEVEL_1_2_EMPTY);

    DL_UART_Main_enable(see_uart_INST);
}

static const DL_UART_Main_ClockConfig gLianganClockConfig = {
    .clockSel    = DL_UART_MAIN_CLOCK_BUSCLK,
    .divideRatio = DL_UART_MAIN_CLOCK_DIVIDE_RATIO_1
};

static const DL_UART_Main_Config gLianganConfig = {
    .mode        = DL_UART_MAIN_MODE_NORMAL,
    .direction   = DL_UART_MAIN_DIRECTION_TX_RX,
    .flowControl = DL_UART_MAIN_FLOW_CONTROL_NONE,
    .parity      = DL_UART_MAIN_PARITY_NONE,
    .wordLength  = DL_UART_MAIN_WORD_LENGTH_8_BITS,
    .stopBits    = DL_UART_MAIN_STOP_BITS_ONE
};

SYSCONFIG_WEAK void SYSCFG_DL_Liangan_init(void)
{
    DL_UART_Main_setClockConfig(Liangan_INST, (DL_UART_Main_ClockConfig *) &gLianganClockConfig);

    DL_UART_Main_init(Liangan_INST, (DL_UART_Main_Config *) &gLianganConfig);
    /*
     * Configure baud rate by setting oversampling and baud rate divisors.
     *  Target baud rate: 115200
     *  Actual baud rate: 115211.52
     */
    DL_UART_Main_setOversampling(Liangan_INST, DL_UART_OVERSAMPLING_RATE_16X);
    DL_UART_Main_setBaudRateDivisor(Liangan_INST, Liangan_IBRD_32_MHZ_115200_BAUD, Liangan_FBRD_32_MHZ_115200_BAUD);



    DL_UART_Main_enable(Liangan_INST);
}

static const DL_SPI_Config gBMI088_config = {
    .mode        = DL_SPI_MODE_CONTROLLER,
    .frameFormat = DL_SPI_FRAME_FORMAT_MOTO4_POL0_PHA0,
    .parity      = DL_SPI_PARITY_NONE,
    .dataSize    = DL_SPI_DATA_SIZE_8,
    .bitOrder    = DL_SPI_BIT_ORDER_MSB_FIRST,
    .chipSelectPin = DL_SPI_CHIP_SELECT_0,
};

static const DL_SPI_ClockConfig gBMI088_clockConfig = {
    .clockSel    = DL_SPI_CLOCK_BUSCLK,
    .divideRatio = DL_SPI_CLOCK_DIVIDE_RATIO_1
};

SYSCONFIG_WEAK void SYSCFG_DL_BMI088_init(void) {
    DL_SPI_setClockConfig(BMI088_INST, (DL_SPI_ClockConfig *) &gBMI088_clockConfig);

    DL_SPI_init(BMI088_INST, (DL_SPI_Config *) &gBMI088_config);

    /* Configure Controller mode */
    /*
     * Set the bit rate clock divider to generate the serial output clock
     *     outputBitRate = (spiInputClock) / ((1 + SCR) * 2)
     *     8000000 = (32000000)/((1 + 1) * 2)
     */
    DL_SPI_setBitRateSerialClockDivider(BMI088_INST, 1);
    /* Set RX and TX FIFO threshold levels */
    DL_SPI_setFIFOThreshold(BMI088_INST, DL_SPI_RX_FIFO_LEVEL_1_2_FULL, DL_SPI_TX_FIFO_LEVEL_1_2_EMPTY);

    /* Enable module */
    DL_SPI_enable(BMI088_INST);
}

static const DL_DMA_Config gDMA_CH0Config = {
    .transferMode   = DL_DMA_SINGLE_TRANSFER_MODE,
    .extendedMode   = DL_DMA_NORMAL_MODE,
    .destIncrement  = DL_DMA_ADDR_INCREMENT,
    .srcIncrement   = DL_DMA_ADDR_UNCHANGED,
    .destWidth      = DL_DMA_WIDTH_BYTE,
    .srcWidth       = DL_DMA_WIDTH_BYTE,
    .trigger        = see_uart_INST_DMA_TRIGGER,
    .triggerType    = DL_DMA_TRIGGER_TYPE_EXTERNAL,
};

SYSCONFIG_WEAK void SYSCFG_DL_DMA_CH0_init(void)
{
    DL_DMA_clearInterruptStatus(DMA, DL_DMA_INTERRUPT_CHANNEL0);
    DL_DMA_enableInterrupt(DMA, DL_DMA_INTERRUPT_CHANNEL0);
    DL_DMA_initChannel(DMA, DMA_CH0_CHAN_ID , (DL_DMA_Config *) &gDMA_CH0Config);
}
SYSCONFIG_WEAK void SYSCFG_DL_DMA_init(void){
    SYSCFG_DL_DMA_CH0_init();
}


