#include "Common_hand.h"


volatile uint8_t Car_start_flag=0 ;


int main(void)
{
    SYSCFG_DL_init();
		Delay_ms(3000);
		bmi088_init();
		Delay_ms(1000);
		Key_Init();
		OLED_Init(OLED_INST);
		while(!Car_start_flag)
		{
				OLED_ShowString(0,0,"Mode:");
				if(mode_num==0)
				{
						OLED_ShowString(30,0,"Nomal");
				}
				else if(mode_num==1)
				{
						OLED_ShowString(30,0,"Renyi");
				}
				else if(mode_num==2)
				{
						OLED_ShowString(30,0,"Distance");
				}
				else if(mode_num==3)
				{
						OLED_ShowString(30,0,"Nomal_30s");
				}
				else if(mode_num==4)
				{
						OLED_ShowString(30,0,"Renyi_30s");
				}
		}
		OLED_Clear();
		xunji_mode=mode_num;
		Delay_ms(100);
		See_Uart_ready();
		Liangan_Init();
		XunJi_Init();
		while(1)
		{
				// 主循环刷新OLED
				if (time_display_flag)
				{
						time_display_flag = 0;
						OLED_Printf(0, 0, "Time:%02d:%02d:%02d", time_h, time_m, time_s);
						OLED_Printf(0,2,"bmi088:%f" ,Accel_Forward );
				}
		}

}
